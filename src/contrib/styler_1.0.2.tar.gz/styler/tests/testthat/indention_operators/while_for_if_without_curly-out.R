while (x > 3)
  return(FALSE)

for (i in 1:3)
  print(i)

if (x)
  call2(3)
