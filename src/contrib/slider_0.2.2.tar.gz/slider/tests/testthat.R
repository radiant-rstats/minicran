library(testthat)
library(slider)

test_check("slider")
