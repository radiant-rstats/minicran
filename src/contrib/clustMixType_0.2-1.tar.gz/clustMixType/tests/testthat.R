library(testthat)
library(clustMixType)

test_check("clustMixType")
