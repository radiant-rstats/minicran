lines.prodlim <- function(x,...){
  plot.prodlim(x,...,add=TRUE)
}
