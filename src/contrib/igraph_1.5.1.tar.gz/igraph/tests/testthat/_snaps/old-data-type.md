# VS/ES require explicit conversion

    Code
      V(karate)
    Error <simpleError>
      This graph was created by a now unsupported old igraph version.
        Call upgrade_version() before using igraph functions on that object.

