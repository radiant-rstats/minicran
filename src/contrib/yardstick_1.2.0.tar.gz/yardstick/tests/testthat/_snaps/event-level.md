# `yardstick_event_level()` ignores option - TRUE, with a warning

    Code
      out <- yardstick_event_level()
    Condition
      Warning:
      The global option `yardstick.event_first` was deprecated in yardstick 0.0.7.
      i Please use the metric function argument `event_level` instead.
      i The global option is being ignored entirely.

# `yardstick_event_level()` ignores option - FALSE, with a warning

    Code
      out <- yardstick_event_level()
    Condition
      Warning:
      The global option `yardstick.event_first` was deprecated in yardstick 0.0.7.
      i Please use the metric function argument `event_level` instead.
      i The global option is being ignored entirely.

