
fun1 <- function() {"fun1"}
.script_version <- "v1.0"
# formals from import::from
.from <- "a script"
.into <- "an env"
.directory <- "my_dir"
