# simple name selections

    Code
      recipes_eval_select(quos = quos(I(date:age)), data = okc, info = info1)
    Error <rlang_error>
      object 'age' not found
      Caused by error in `unique.default()`:
      ! object 'age' not found

