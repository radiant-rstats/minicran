globalVariables(".rs.restartR")

#' radiant.update
#'
#' @name radiant.update
#' @importFrom utils new.packages old.packages available.packages installed.packages compareVersion sessionInfo remove.packages
#'
NULL
