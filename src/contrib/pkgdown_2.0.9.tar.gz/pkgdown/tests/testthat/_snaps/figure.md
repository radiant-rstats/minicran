# can override defaults in _pkgdown.yml

    Code
      build_reference(pkg, devel = FALSE)
    Message
      -- Building function reference -------------------------------------------------
      Writing `reference/index.html`
      Reading man/figure.Rd
      Writing `reference/figure.html`

---

    Code
      build_articles(pkg)
    Message
      -- Building articles -----------------------------------------------------------
      Writing `articles/index.html`
      Reading vignettes/figures.Rmd
      Writing `articles/figures.html`

