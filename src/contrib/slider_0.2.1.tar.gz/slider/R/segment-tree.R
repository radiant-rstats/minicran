# Keep in line with `segment-tree.h`
SEGMENT_TREE_FANOUT = 16
SEGMENT_TREE_FANOUT_POWER = 4
