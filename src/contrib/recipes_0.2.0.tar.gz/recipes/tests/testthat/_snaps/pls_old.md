# check old PLS scores from recipes version <= 0.1.12

    Code
      new_values_te <- bake(old_pls, biom_te)
    Warning <rlang_warning>
      'keep_original_cols' was added to `step_pls()` after this recipe was created.
      Regenerate your recipe to avoid this warning.

