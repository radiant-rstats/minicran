# deprecated `future_options()` warns when used

    Code
      future_options()
    Warning <lifecycle_warning_deprecated>
      `future_options()` is deprecated as of furrr 0.2.0.
      Please use `furrr_options()` instead.
    Output
      <furrr_options>

