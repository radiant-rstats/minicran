# validates inputs

    Code
      slowly(mean, 10)
    Condition
      Error in `slowly()`:
      ! `rate` must be a rate object, not a number.

