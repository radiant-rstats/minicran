value <- 5
if (value > 0) {
    print(value)
}



if (value > 0) {
    print(value)
}
