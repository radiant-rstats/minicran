# missing title generates useful message

    Code
      roc_proc_text(rd_roclet(), block)
    Condition
      Warning:
      Skipping 'foo.Rd'
      i File lacks name and/or title
    Output
      named list()

