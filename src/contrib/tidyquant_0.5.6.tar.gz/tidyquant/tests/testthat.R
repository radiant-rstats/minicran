library(testthat)
library(tidyquant)

test_check("tidyquant")
