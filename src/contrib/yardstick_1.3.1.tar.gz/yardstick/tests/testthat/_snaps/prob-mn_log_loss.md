# errors with class_pred input

    Code
      mn_log_loss_vec(cp_truth, estimate)
    Condition
      Error in `mn_log_loss_vec()`:
      ! `truth` should not a <class_pred> object.

