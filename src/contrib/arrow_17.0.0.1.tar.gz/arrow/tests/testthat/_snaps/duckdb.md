# meaningful error message when duckdb is not installed

    Code
      to_duckdb(ds)
    Error <rlang_error>
      Please install the `duckdb` package to pass data with `to_duckdb()`.

