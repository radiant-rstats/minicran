library(testthat)
library(stopwords)

test_check("stopwords")
