globalVariables(c("name", "name1", "timestamp", "val", "value", "value1", "change"))
