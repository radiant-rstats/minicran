#' @aliases ggraph-package
#' @keywords internal
'_PACKAGE'

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @import ggplot2 tidygraph rlang vctrs
#' @importFrom lifecycle deprecated
#' @importFrom Rcpp sourceCpp
#' @useDynLib ggraph
## usethis namespace: end
NULL
