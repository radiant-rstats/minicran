#' @export
#' @importFrom ggdist parse_dist
ggdist::parse_dist

#' @export
#' @importFrom ggdist r_dist_name
ggdist::r_dist_name
