#' @rdname dbBind
#' @export
setGeneric("dbBindArrow",
  def = function(res, params, ...) standardGeneric("dbBindArrow")
)
