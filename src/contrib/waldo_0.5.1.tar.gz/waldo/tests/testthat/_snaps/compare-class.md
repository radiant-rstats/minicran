# print method covers main cases

    Code
      new_compare()
    Output
      v No differences
    Code
      new_compare(letters[1:3])
    Output
      a
      
      b
      
      c
    Code
      new_compare(letters[1:11])
    Output
      a
      
      b
      
      c
      
      d
      
      e
      
      f
      
      g
      
      h
      
      i
      
      j
      
      And 1 more differences ...

