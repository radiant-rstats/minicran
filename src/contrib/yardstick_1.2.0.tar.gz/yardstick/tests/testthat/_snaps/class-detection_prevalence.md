# work with class_pred input

    Code
      detection_prevalence_vec(cp_truth, cp_estimate)
    Condition
      Error in `detection_prevalence_vec()`:
      ! `truth` should not a `class_pred` object.

