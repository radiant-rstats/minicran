# Getting a graph from a series is possible

    Code
      create_graph_series() %>% get_graph_from_graph_series(graph_no = 1)
    Condition
      Error in `get_graph_from_graph_series()`:
      ! There are no graphs in this graph series.

