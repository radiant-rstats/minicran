# collect_notes works

    Code
      collect_notes(wflow_set)
    Condition
      Error in `halt()`:
      ! There were 2 workflows that had no results.

