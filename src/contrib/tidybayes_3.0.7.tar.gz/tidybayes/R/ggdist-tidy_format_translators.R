#' @export
#' @importFrom ggdist to_broom_names
ggdist::to_broom_names

#' @export
#' @importFrom ggdist from_broom_names
ggdist::from_broom_names

#' @export
#' @importFrom ggdist to_ggmcmc_names
ggdist::to_ggmcmc_names

#' @export
#' @importFrom ggdist from_ggmcmc_names
ggdist::from_ggmcmc_names
