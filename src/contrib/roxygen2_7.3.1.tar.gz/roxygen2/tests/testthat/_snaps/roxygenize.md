# can regenerate NAMESPACE even if its broken

    Code
      roxygenise(path)
    Message
      Writing 'NAMESPACE'
      i Loading brokenNamespace
      Writing 'NAMESPACE'

