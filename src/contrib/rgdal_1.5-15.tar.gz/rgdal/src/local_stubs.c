/* use same define in package's own header file */
#define SP_XPORT(x) RGDAL_ ## x
#include "sp_xports.c"
/* touch 121019 */
