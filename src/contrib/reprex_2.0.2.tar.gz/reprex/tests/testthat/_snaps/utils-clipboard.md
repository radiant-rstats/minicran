# reprex_clipboard() insists on length one logical

    Code
      reprex_clipboard()
    Condition
      Error:
      ! The `reprex.clipboard` option must be `TRUE`, `FALSE`, or (logical) `NA`.

