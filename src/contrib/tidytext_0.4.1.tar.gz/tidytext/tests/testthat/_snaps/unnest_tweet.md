# unnest_tweet works

    `unnest_tokens()` was deprecated in tidytext 0.4.0 and is now defunct.

