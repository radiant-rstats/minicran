#' @export
#' @importFrom ggdist curve_interval
ggdist::curve_interval
