## ---- eval = FALSE------------------------------------------------------------
#  Sys.unsetenv("AWS_DEFAULT_REGION")
#  Sys.unsetenv("AWS_S3_ENDPOINT")

## ---- eval = FALSE------------------------------------------------------------
#  Sys.setenv(AWS_EC2_METADATA_DISABLED = TRUE)

