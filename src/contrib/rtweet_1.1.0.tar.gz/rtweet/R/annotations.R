#'
#' @references <https://developer.twitter.com/en/docs/twitter-api/annotations/overview>
