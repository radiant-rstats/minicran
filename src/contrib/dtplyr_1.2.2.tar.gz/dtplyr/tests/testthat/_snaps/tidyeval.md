# translates lag()/lead()

    The `order_by` argument of `lag()` is not supported by dtplyr

# desc() checks the number of arguments

    Code
      capture_dot(df, desc(a, b))
    Error <rlang_error>
      `desc()` expects exactly one argument.

