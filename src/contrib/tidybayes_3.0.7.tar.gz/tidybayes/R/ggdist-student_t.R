#' @export
#' @importFrom ggdist dstudent_t
ggdist::dstudent_t

#' @export
#' @importFrom ggdist pstudent_t
ggdist::pstudent_t

#' @export
#' @importFrom ggdist qstudent_t
ggdist::qstudent_t

#' @export
#' @importFrom ggdist rstudent_t
ggdist::rstudent_t
