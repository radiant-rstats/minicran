#' @importFrom generics generate
#' @export
generics::generate
