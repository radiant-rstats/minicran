# a comment
call(
1,
call2(
2, 3,
call3(# zero
# one
                   # two2
      1, 2 # two
      , 22 # comment
      ),
    5
  ), #' A roxygen comment
                 144
                  # anotehr indented comment
)

# new comment




a()
# I think it gets boring
# new_line here
b(x, y, 7)  # hidden?
# comments belong to previous token.


# last comemnt EOF
