# extracts

    Code
      car_set_1 %>% extract_workflow_set_result("Gideon Nav")
    Error <rlang_error>
      `id` must correspond to a single row in `x`.

---

    Code
      car_set_1 %>% extract_workflow("Coronabeth Tridentarius")
    Error <rlang_error>
      `id` must correspond to a single row in `x`.

