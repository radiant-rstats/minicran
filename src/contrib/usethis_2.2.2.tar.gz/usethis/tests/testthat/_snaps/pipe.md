# use_pipe(export = FALSE) adds roxygen to package doc

    Code
      roxygen_ns_show()
    Output
      [1] "#' @importFrom magrittr %>%"

