# Registered in `.onLoad()`
dplyr_reconstruct_parameters <- function(data, template) {
  parameters_reconstruct(data, template)
}
