#' @export
dplyr_reconstruct.workflow_set <- function(data, template) {
   workflow_set_maybe_reconstruct(data)
}
