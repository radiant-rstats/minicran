#' @export
#' @importFrom ggdist dlkjcorr_marginal
ggdist::dlkjcorr_marginal

#' @export
#' @importFrom ggdist plkjcorr_marginal
ggdist::plkjcorr_marginal

#' @export
#' @importFrom ggdist qlkjcorr_marginal
ggdist::qlkjcorr_marginal

#' @export
#' @importFrom ggdist rlkjcorr_marginal
ggdist::rlkjcorr_marginal

#' @export
#' @importFrom ggdist marginalize_lkjcorr
ggdist::marginalize_lkjcorr
