# `data` must be data-like

    Code
      shrink(1, ptype)
    Condition
      Error in `shrink()`:
      ! `data` must be a data frame or a matrix, not the number 1.

