library(testthat)
library(lfe)

test_check("lfe")
