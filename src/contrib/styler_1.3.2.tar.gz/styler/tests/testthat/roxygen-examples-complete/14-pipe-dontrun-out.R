#' Hi
#'
#' x
#' @examples
#' a %>%
#'   x(b = 3) %>%
#'   ff()
#' \dontrun{
#' style_pkg(
#'   scope = "line_breaks",
#'   math_token_spacing = specfy_math_token_spacing(zero = "'+'")
#' ) %>%
#'   there()
#' }
#' call("\\n", x = 3)
#' @export
NULL
