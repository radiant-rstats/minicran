library(testthat)
library(EnvStats)
test_check("EnvStats")
