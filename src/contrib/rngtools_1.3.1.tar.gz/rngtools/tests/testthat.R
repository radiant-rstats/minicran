library(testthat)
library(rngtools)

test_check("rngtools")
