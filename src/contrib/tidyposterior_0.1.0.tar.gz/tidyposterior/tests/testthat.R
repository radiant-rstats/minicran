library(testthat)
library(tidyposterior)

test_check("tidyposterior")
