
# 1.2.0

* New symbol: `double_line`: ═

* New block symbols: `upper_block_1`: ▔, `upper_block_4`: ▀,
  `lower_block_1`: ▁, etc. `lower_block_8`: █
  (`lower_block_8` is also known as `full_block`.)

* Better detection of UTF-8 support: use the official `l10n_info()`
  function

# 1.1.0

Three more symbols: `neq`: ≠, `geq`: ≥, `leq`: ≤

# 1.0.0

First released version.
