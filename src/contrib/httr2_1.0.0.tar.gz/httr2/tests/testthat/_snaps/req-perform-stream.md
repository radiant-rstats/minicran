# req_stream() is deprecated

    Code
      resp <- req_stream(req, identity, buffer_kb = 32)
    Condition
      Warning:
      `req_stream()` was deprecated in httr2 1.0.0.
      i Please use `req_perform_stream()` instead.

