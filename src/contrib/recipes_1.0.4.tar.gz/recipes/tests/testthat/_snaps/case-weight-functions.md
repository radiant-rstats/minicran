# is_unsupervised_weights works

    Code
      is_unsupervised_weights(3)
    Condition
      Error in `is_unsupervised_weights()`:
      ! Must be be a case_weights variable

