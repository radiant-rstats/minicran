#ifndef WIN_R_BUILD
#if __cplusplus < 201402L
#error Error: ranger requires a C++14 compiler, e.g., gcc >= 5 or Clang >= 3.4. You probably have to update your C++ compiler.
#endif
#endif

