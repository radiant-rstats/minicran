gofTest <-
function (y, ...) 
UseMethod("gofTest")
