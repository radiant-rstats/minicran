if (requireNamespace("testthat", quietly = TRUE)) {

  library(testthat)
  library(RcppRoll)

  test_check("RcppRoll")

}
