# list-along is deprecated

    Code
      . <- list_along(1:4)
    Condition
      Warning:
      `list_along()` was deprecated in purrr 1.0.0.
      i Please use rep_along(x, list()) instead.

