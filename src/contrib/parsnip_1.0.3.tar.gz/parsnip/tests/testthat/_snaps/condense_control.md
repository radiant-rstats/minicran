# condense_control works

    Code
      condense_control(control_parsnip(), ctrl)
    Condition
      Error in `condense_control()`:
      ! Object of class `control_parsnip` cannot be coerced to object of class `control_parsnip`.
      * The following arguments are missing:
      * 'allow_par', and 'anotherone'

