# `run_mold()` throws an informative default error

    Code
      run_mold(1)
    Condition
      Error in `run_mold()`:
      ! No `run_mold()` method provided for an object of type <numeric>.

