library(testthat)
test_check("shinyAce")