# distinct throws error if column is specified and .keep_all is TRUE

    Can only find distinct value of specified columns if .keep_all is FALSE

