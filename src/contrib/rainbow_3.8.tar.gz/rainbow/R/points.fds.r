points.fds <- function (x, type = "p", index, ...) 
{
   plot.fds(x = x, type = type, add = TRUE, index = index, ...)
}