# not marginal plot with grid search

    Code
      autoplot(knn_results, type = "performance")
    Condition
      Error in `autoplot()`:
      ! `type = performance` is only used iterative search results.

---

    Code
      autoplot(knn_results, type = "parameters")
    Condition
      Error in `autoplot()`:
      ! `type = parameters` is only used iterative search results.

# coord_obs_pred

    Removed 1 rows containing missing values (`geom_point()`).

