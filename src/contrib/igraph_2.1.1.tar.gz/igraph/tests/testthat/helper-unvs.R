unvs <- function(x) lapply(x, as.vector)
