# Confusion Matrix - type argument

    Code
      ggplot2::autoplot(res, type = "wrong")
    Condition
      Error in `ggplot2::autoplot()`:
      ! `type` must be one of "mosaic" or "heatmap", not "wrong".

