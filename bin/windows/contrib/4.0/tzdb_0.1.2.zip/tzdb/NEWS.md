# tzdb 0.1.2

* Updated the embedded date library.

# tzdb 0.1.1

* tzdb now provides C++ headers and callables for working with the 'date'
  library. 'date' provides comprehensive support for working with dates and
  date-times, which this package exposes to make it easier for other R packages
  to utilize.

# tzdb 0.1.0

* Added a `NEWS.md` file to track changes to the package.
