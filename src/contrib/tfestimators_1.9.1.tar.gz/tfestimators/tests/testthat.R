

library(testthat)
library(tfestimators)

test_check("tfestimators")
