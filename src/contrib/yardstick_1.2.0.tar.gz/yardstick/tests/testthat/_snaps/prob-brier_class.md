# errors with class_pred input

    Code
      brier_class_vec(cp_truth, estimate)
    Condition
      Error in `brier_class_vec()`:
      ! `truth` should not a `class_pred` object.

