function(y = {}) NULL

function(y =
           {}) {
  NULL
}

function(yyy = {
           1
         }) {
  1
}

function(yyy = {
           1
         }) {
  1
}

f1 <- function(x = {
                 1
               }, y = 0) {
  c(x, y)
}
