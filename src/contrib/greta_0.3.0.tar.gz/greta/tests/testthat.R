library(testthat)
library(tensorflow)
library(greta)
library(fields)

test_check("greta")
