# get_timelines() is deprecated

    Code
      x <- get_timelines("cnn", n = 10)
    Condition
      Warning:
      `get_timelines()` was deprecated in rtweet 1.0.0.
      i Please use `get_timeline()` instead.

