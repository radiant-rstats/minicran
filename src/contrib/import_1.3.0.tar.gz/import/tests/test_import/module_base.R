
fun1 <- function() {"fun1"}
fun2 <- function() {"fun2"}
fun3 <- function() {"fun3"}
fun4 <- function() {"fun4"}
fun5 <- function() {"fun5"}
fun6 <- function() {"fun6"}
