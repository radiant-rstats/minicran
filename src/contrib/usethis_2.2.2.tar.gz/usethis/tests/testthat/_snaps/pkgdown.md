# use_pkgdown() creates and ignores the promised file/dir

    Code
      use_pkgdown()
    Message
      v Adding '^_pkgdown\\.yml$', '^docs$', '^pkgdown$' to '.Rbuildignore'
      v Adding 'docs' to '.gitignore'
      v Writing '_pkgdown.yml'
      * Edit '_pkgdown.yml'

