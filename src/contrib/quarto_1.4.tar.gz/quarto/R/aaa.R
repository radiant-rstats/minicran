#' Internal package state
#' @noRd
quarto <- new.env(parent = emptyenv())
