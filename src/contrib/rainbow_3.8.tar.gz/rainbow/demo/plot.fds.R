## This demo considers functional data visualization using fds().

library(rainbow)

plot(fds(x = 1:20, y = Simulationdata$y, xname = "x", yname = "Simulated value"))




