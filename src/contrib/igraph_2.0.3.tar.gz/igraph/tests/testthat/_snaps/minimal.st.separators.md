# min_st_separators() works for the note case

    Code
      min_st_separators(g)
    Output
      [[1]]
      + 1/5 vertex, named, from something
      [1] 1
      
      [[2]]
      + 2/5 vertices, named, from something
      [1] 2 4
      
      [[3]]
      + 2/5 vertices, named, from something
      [1] 1 3
      

