library(testthat)
library(s2)

test_check("s2")
