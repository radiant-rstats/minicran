//#include <stdlib.h>
#include <stddef.h>

	double kendallNlogN  (double* arr1, double* arr2, size_t len, int cor) ;
	double kendallSmallN (double* arr1, double* arr2, size_t len, int cor) ;
