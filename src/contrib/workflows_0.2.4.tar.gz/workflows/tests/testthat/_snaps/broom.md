# can't glance at the model of an unfit workflow

    The workflow does not have a model fit. Have you called `fit()` yet?

# can't augment with the model of an unfit workflow

    The workflow does not have a model fit. Have you called `fit()` yet?

