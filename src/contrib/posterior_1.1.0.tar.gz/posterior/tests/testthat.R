library(testthat)
library(posterior)

test_check("posterior")
