# queries translate correctly

    Code
      mf %>% head()
    Output
      <SQL>
      SELECT TOP 6 `df`.*
      FROM `df`

