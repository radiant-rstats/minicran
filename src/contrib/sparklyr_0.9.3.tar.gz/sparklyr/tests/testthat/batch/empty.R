message("Empty batch script")
