# time filtering

    There were 3 inappropriate evaluation time points that were removed.

---

    There was 1 inappropriate evaluation time point that was removed.

---

    Code
      parsnip:::.filter_eval_time(-1)
    Condition
      Error:
      ! There were no usable evaluation times (finite, non-missing, and >= 0).

