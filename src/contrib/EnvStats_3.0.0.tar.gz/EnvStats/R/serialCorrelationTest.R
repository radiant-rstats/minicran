serialCorrelationTest <-
function (x, ...) 
UseMethod("serialCorrelationTest")
