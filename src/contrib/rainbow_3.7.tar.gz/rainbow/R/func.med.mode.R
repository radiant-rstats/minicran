func.med.mode <- function(funciones, p = 2)
{
  depth.mode(funciones, p = p)$median
}
