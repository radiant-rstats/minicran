# accessor functions for `val_split`

    Code
      testing(val_split)
    Condition
      Error in `testing()`:
      ! The testing data is not part of the validation set object.

