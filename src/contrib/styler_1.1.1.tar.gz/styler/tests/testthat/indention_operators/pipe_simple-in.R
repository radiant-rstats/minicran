   a %>%
b() %>%
c() %>%
          d(1 + e (sin(f))) %>%
                                 g_out()

a <- function(jon_the_pipe) {}
