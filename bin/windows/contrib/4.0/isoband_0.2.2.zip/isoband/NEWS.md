isoband 0.2.2
----------------------------------------
- Remove Rcpp dependency (#11, @thomasp85).

isoband 0.2.1
----------------------------------------
- Improved clipping algorithm for `clip_lines()`, less likely to
  experience numerical instabilities.


isoband 0.2.0
----------------------------------------
- Added `isolines_grob()` for drawing labeled isolines via the grid graphics system.
  A companion function `isobands_grob()` is provided for convenience.
  
- Numerous minor fixes and improvements.

isoband 0.1.0
----------------------------------------
First public release.
