# simple name selections

    Code
      recipes_eval_select(quos = quos(I(beds:sqft)), data = Sacramento, info = info1)
    Condition
      Error in `unique.default()`:
      ! object 'beds' not found

