# checks its inputs

    Code
      pause(c(1, 2))
    Condition
      Error in `pause()`:
      ! `seconds` must be a single number.
    Code
      pause("a")
    Condition
      Error in `pause()`:
      ! `seconds` must be a single number.

