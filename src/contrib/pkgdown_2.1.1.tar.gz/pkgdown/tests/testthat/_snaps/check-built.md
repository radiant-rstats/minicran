# check images in readme

    Code
      check_built_site(pkg)
    Message
      -- Checking for problems -------------------------------------------------------
      Missing images in 'README.md': 'articles/kitten.jpg'
      i pkgdown can only use images in 'man/figures' and 'vignettes'

