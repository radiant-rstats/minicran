
delayedAssign("foo", rlang::signal("", "forced"))

#' @export
delayedAssign("bar", rlang::signal("", "forced"))
