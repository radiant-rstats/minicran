switch(engine,
    pdftex = {
     if (any) {
              x
            }
         },
       new=(
      2
       )   )

{
  a <-
    3
}
