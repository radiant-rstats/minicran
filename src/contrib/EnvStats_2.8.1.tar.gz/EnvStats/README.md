[![R-CMD-check](https://github.com/alexkowa/EnvStats/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/alexkowa/EnvStats/actions/workflows/R-CMD-check.yaml)
[![Codecov test coverage](https://codecov.io/gh/alexkowa/EnvStats/branch/master/graph/badge.svg)](https://app.codecov.io/gh/alexkowa/EnvStats?branch=master)
[![CRAN](http://www.r-pkg.org/badges/version/EnvStats)](https://CRAN.R-project.org/package=EnvStats)
[![Downloads](http://cranlogs.r-pkg.org/badges/EnvStats)](https://CRAN.R-project.org/package=EnvStats)

## EnvStats

This is the development place for R-package EnvStats

Author: Steven P. Millard

Maintainer: Alexander Kowarik
