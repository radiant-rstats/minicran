#include <rstan_next/stan_fit_base.hpp>

namespace rstan {

stan_fit_base::~stan_fit_base() {}

}
