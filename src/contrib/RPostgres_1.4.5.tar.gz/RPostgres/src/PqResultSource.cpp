#include "pch.h"
#include "PqResultSource.h"

PqResultSource::PqResultSource() {
}

PqResultSource::~PqResultSource() {
}
