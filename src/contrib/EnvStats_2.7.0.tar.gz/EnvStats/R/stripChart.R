stripChart <-
function (x, ...) 
UseMethod("stripChart")
