# errors on unsupported types

    no applicable method for 'invalid_remove' applied to an object of class "c('double', 'numeric')"

