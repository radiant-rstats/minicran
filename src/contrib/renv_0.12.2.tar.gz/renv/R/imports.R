
#' @importFrom utils adist available.packages citation contrib.url download.file
#'   download.packages file.edit getCRANmirrors head help install.packages
#'   installed.packages old.packages packageDescription packageVersion
#'   read.table remove.packages sessionInfo str tail tar toBibtex untar
#'   update.packages unzip URLencode zip
NULL
