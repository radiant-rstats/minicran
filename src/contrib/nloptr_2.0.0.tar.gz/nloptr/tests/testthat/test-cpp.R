skip_if_not_installed("xml2")
run_cpp_tests("nloptr")
