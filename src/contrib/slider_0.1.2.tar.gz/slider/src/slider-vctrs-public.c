#include <vctrs.c>

void slider_init_vctrs_public() {
  vctrs_init_api();
}
