![Build Status](https://travis-ci.org/alexkowa/EnvStats.svg?branch=master)
[![Coverage Status](https://coveralls.io/repos/github/alexkowa/EnvStats/badge.svg?branch=master)](https://coveralls.io/github/alexkowa/EnvStats?branch=master)
[![CRAN](http://www.r-pkg.org/badges/version/EnvStats)](https://CRAN.R-project.org/package=EnvStats)
[![Downloads](http://cranlogs.r-pkg.org/badges/EnvStats)](https://CRAN.R-project.org/package=EnvStats)

## EnvStats

This is the development place for R-package EnvStats

Author: Steven P. Millard

Maintainer: Alexander Kowarik
