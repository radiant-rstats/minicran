# novel levels can be ignored

    Code
      x <- scream(new, ptype, allow_novel_levels = TRUE)

# novel levels in a new character vector can be ignored

    Code
      x <- scream(new, ptype, allow_novel_levels = TRUE)

