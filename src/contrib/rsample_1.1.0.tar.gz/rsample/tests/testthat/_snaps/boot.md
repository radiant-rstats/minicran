# bad args

    Code
      group_bootstraps(warpbreaks, tension)
    Condition
      Error in `group_bootstraps()`:
      ! Some assessment sets contained zero rows
      i Consider using a non-grouped resampling method

# printing

    Code
      set.seed(11)
      bootstraps(warpbreaks)
    Output
      # Bootstrap sampling 
      # A tibble: 25 x 2
         splits          id         
         <list>          <chr>      
       1 <split [54/20]> Bootstrap01
       2 <split [54/22]> Bootstrap02
       3 <split [54/17]> Bootstrap03
       4 <split [54/22]> Bootstrap04
       5 <split [54/17]> Bootstrap05
       6 <split [54/19]> Bootstrap06
       7 <split [54/18]> Bootstrap07
       8 <split [54/17]> Bootstrap08
       9 <split [54/23]> Bootstrap09
      10 <split [54/22]> Bootstrap10
      # ... with 15 more rows
      # i Use `print(n = ...)` to see more rows

