# constant distributions work

    list(thickness = Inf, pdf = Inf, cdf = 1, x = 1, ymin = 0, ymax = 1)

---

    list(thickness = 0, pdf = 0, cdf = 0, x = 0, ymin = 0, ymax = 1)

