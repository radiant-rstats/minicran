#ifndef RCPP_dplyr_dplyr_H
#define RCPP_dplyr_dplyr_H

#include <dplyr/main.h>

#endif // RCPP_dplyr_H_GEN_
