library(testthat)
library(graphlayouts)

test_check("graphlayouts")
