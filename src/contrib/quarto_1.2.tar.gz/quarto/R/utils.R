

relative_to_wd <- function(path) {
  relative_to(getwd(), path)
}
