new_date <- function(x = double()) {
  vctrs::new_date(as.double(x))
}
