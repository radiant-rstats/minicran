print_text = function(text){
  print(text)
}
