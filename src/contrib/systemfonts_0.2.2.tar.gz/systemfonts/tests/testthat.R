library(testthat)
library(systemfonts)

test_check("systemfonts")
