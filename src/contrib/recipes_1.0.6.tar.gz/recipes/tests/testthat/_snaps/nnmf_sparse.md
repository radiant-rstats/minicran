# check_name() is used

    Code
      prep(rec, training = dat)
    Condition
      Error in `step_nnmf_sparse()`:
      Caused by error in `bake()`:
      ! Name collision occured. The following variable names already exists:
      i  NNMF1

