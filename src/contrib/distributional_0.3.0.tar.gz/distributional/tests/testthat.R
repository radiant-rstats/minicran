library(testthat)
library(distributional)

test_check("distributional")
