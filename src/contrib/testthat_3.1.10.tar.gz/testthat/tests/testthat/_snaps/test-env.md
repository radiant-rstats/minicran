# is_snapshot() is true in snapshots

    Code
      is_snapshot()
    Output
      [1] TRUE

---

    true

---

    [1] TRUE

---

    Is snapshotting!

---

    Is snapshotting!

