#' @export
internal <- function() NULL
