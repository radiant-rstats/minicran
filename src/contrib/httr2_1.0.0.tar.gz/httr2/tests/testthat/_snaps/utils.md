# modify list adds, removes, and overrides

    Code
      modify_list(x, a = 1, 2)
    Condition
      Error:
      ! All components of `...` must be named.

# can suppress progress bar

    Code
      sys_sleep(0.1, "for test")
    Message
      > Waiting 1s for test

