# warn if forgotton colom

    [<text>:4] @section title spans multiple lines.
    i Did you forget a colon (:) at the end of the title?

