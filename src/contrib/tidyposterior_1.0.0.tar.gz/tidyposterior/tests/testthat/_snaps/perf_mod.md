# basic usage

    Code
      print(obj_1)
    Output
      Bayesian Analysis of Resampling Results
      Original data: Bootstrap sampling
      

# data frame method

    Code
      print(obj_2)
    Output
      Bayesian Analysis of Resampling Results
      

# rsample method

    Code
      print(obj_4)
    Output
      Bayesian Analysis of Resampling Results
      

# rsample method with repeated cv

    Code
      print(obj_5)
    Output
      Bayesian Analysis of Resampling Results
      Original data: 5-fold cross-validation repeated 2 times
      

# repeated v_fold method

    Code
      print(obj_6)
    Output
      Bayesian Analysis of Resampling Results
      Original data: 5-fold cross-validation repeated 2 times
      

