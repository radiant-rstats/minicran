# flat tables

    Code
      yardstick:::flatten(three_class_tb[, 1:2])
    Condition
      Error:
      ! `x` must have equal dimensions. `x` has 2 columns and 3 rows.

