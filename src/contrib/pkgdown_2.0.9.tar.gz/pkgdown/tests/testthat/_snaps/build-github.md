# a CNAME record is built if a url exists in metadata

    Code
      build_github_pages(pkg)
    Message
      -- Extra files for GitHub pages ------------------------------------------------
      Writing `.nojekyll`
      Writing `CNAME`

