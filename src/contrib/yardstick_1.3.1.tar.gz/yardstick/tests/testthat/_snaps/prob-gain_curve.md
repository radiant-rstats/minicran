# error handling

    Code
      gain_curve(df, truth, estimate)
    Condition
      Error in `gain_curve()`:
      ! `truth` should be a factor, not a a number.

# errors with class_pred input

    Code
      gain_curve_vec_vec(cp_truth, estimate)
    Condition
      Error in `gain_curve_vec_vec()`:
      ! could not find function "gain_curve_vec_vec"

