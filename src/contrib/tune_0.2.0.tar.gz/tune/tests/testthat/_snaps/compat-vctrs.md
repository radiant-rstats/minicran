# vec_cast() is working

    Code
      vec_cast(x, x)
    Error <vctrs_error_incompatible_type>
      Can't convert <resample_results> to <resample_results>.
      Can't cast to a <resample_results> because attributes are likely incompatible.

---

    Code
      vec_cast(tbl, x)
    Error <vctrs_error_incompatible_type>
      Can't convert <tibble> to <resample_results>.
      Can't cast to a <resample_results> because attributes are likely incompatible.

---

    Code
      vec_cast(df, x)
    Error <vctrs_error_incompatible_type>
      Can't convert <data.frame> to <resample_results>.
      Can't cast to a <resample_results> because attributes are likely incompatible.

---

    Code
      vec_cast(x, x)
    Error <vctrs_error_incompatible_type>
      Can't convert <tune_results> to <tune_results>.
      Can't cast to a <tune_results> because attributes are likely incompatible.

---

    Code
      vec_cast(tbl, x)
    Error <vctrs_error_incompatible_type>
      Can't convert <tibble> to <tune_results>.
      Can't cast to a <tune_results> because attributes are likely incompatible.

---

    Code
      vec_cast(df, x)
    Error <vctrs_error_incompatible_type>
      Can't convert <data.frame> to <tune_results>.
      Can't cast to a <tune_results> because attributes are likely incompatible.

---

    Code
      vec_cast(x, x)
    Error <vctrs_error_incompatible_type>
      Can't convert <iteration_results> to <iteration_results>.
      Can't cast to a <iteration_results> because attributes are likely incompatible.

---

    Code
      vec_cast(tbl, x)
    Error <vctrs_error_incompatible_type>
      Can't convert <tibble> to <iteration_results>.
      Can't cast to a <iteration_results> because attributes are likely incompatible.

---

    Code
      vec_cast(df, x)
    Error <vctrs_error_incompatible_type>
      Can't convert <data.frame> to <iteration_results>.
      Can't cast to a <iteration_results> because attributes are likely incompatible.

