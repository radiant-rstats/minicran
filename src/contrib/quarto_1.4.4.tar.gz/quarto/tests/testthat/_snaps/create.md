# Create a quarto project

    Code
      quarto_create_project()
    Condition
      Error in `quarto_create_project()`:
      ! You need to provide `name` for the new project.

