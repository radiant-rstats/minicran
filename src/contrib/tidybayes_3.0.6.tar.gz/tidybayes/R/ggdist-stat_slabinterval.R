#' @export
#' @importFrom ggdist stat_slabinterval
ggdist::stat_slabinterval

#' @export
#' @importFrom ggdist StatSlabinterval
ggdist::StatSlabinterval
