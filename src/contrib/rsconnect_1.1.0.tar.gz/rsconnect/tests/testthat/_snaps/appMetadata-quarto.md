# quartoInspect requires quarto

    Code
      quartoInspect()
    Condition
      Error in `quartoInspect()`:
      ! `quarto` not found.
      i Check that it is installed and available on your `PATH`.

