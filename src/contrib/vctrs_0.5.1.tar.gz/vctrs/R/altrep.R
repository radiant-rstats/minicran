is_altrep <- function(x) {
  .Call(vctrs_is_altrep, x)
}
