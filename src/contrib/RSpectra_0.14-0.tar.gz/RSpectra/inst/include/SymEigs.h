#ifndef SYMEIGS_H
#define SYMEIGS_H

#ifdef __cplusplus
#include <Spectra/SymEigsSolver.h>
#include <Spectra/SymEigsShiftSolver.h>
#endif

#endif /* SYMEIGS_H */
