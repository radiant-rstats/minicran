library(testthat)
library(riingo)

test_check("riingo")
