# existing logo generates message

    Code
      build_favicons(pkg)
    Output
      -- Building favicons -----------------------------------------------------------
    Message
      Favicons already exist in `pkgdown/`. Set `overwrite = TRUE` to re-create.

