# errors with class_pred input

    Code
      pr_auc_vec(cp_truth, estimate)
    Condition
      Error in `pr_auc_vec()`:
      ! `truth` should not a <class_pred> object.

