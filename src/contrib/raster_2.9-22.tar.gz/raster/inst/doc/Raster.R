### R code from vignette source 'Raster.Rnw'

###################################################
### code chunk number 1: foo
###################################################
options(width = 60)
foo <- packageDescription("raster")


