# markdown_text_inline() works with inline markdown

    Can't use a block element in `<inline>`, need an inline element: `x y`

