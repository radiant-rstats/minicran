if(FALSE){ #Set to TRUE to enable test

library(testthat)
library(network)

test_check("network")

}
