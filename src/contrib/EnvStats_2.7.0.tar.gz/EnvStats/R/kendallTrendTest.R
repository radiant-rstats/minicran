kendallTrendTest <-
function (y, ...) 
UseMethod("kendallTrendTest")
