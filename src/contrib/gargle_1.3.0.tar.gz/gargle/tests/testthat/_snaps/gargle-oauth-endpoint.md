# gargle_oauth_endpoint() snapshot

    Code
      gargle_oauth_endpoint()
    Output
      <oauth_endpoint>
       authorize: https://accounts.google.com/o/oauth2/v2/auth
       access:    https://oauth2.googleapis.com/token
       validate:  https://oauth2.googleapis.com/tokeninfo
       revoke:    https://oauth2.googleapis.com/revoke

