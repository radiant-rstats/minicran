# CHANGES IN radiant.data VERSION 0.2.1

## BUG FIXES

- Fix for `create_repo` when group already exists
- Updated links to source code and issue tracker
- Export main functions

