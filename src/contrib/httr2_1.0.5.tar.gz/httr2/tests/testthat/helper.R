testthat::set_state_inspector(function() {
  getAllConnections()
})
