# work with class_pred input

    Code
      bal_accuracy(cp_truth, cp_estimate)
    Condition
      Error in `UseMethod()`:
      ! no applicable method for 'bal_accuracy' applied to an object of class "c('class_pred', 'vctrs_vctr')"

