# check_bootswatch_theme() works

    Can't find Bootswatch theme 'paper' (template.bootswatch) for Bootstrap version '4' (template.bootstrap).

# capture data_template()

    package:
      name: testpackage
      version: 1.0.0
    logo:
      src: ~
    site:
      root: ''
      title: testpackage
    year: <year>
    lang: en
    translate:
      skip: Skip to contents
      toggle_nav: Toggle navigation
      search_for: Search for
      on_this_page: On this page
      source: Source
      abstract: Abstract
      authors: Authors
      version: Version
      examples: Examples
      citation: Citation
    has_favicons: no
    opengraph: []
    extra:
      css: ~
      js: ~
    includes: []
    yaml:
      .present: yes
    development:
      destination: dev
      mode: default
      version_label: default
      in_dev: no
      version_tooltip: ''
    navbar:
      type: default
      left: |-
        <li>
          <a href="reference/index.html">Reference</a>
        </li>
      right: ''
    footer:
      left: <p>Developed by Hadley Wickham, RStudio.</p>
      right: <p>Site built with <a href="https://pkgdown.r-lib.org/">pkgdown</a> {version}.</p>
    

