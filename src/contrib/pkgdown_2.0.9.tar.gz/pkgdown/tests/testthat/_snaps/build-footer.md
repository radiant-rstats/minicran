# works by default

    $left
    [1] "<p>Developed by First Last.</p>"
    
    $right
    [1] "<p>Site built with <a href=\"https://pkgdown.r-lib.org/\">pkgdown</a> {version}.</p>"
    

