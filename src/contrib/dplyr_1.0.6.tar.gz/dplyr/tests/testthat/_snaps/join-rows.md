# join_rows() gives meaningful error message on incompatible types

    Code
      join_rows(data.frame(x = 1), data.frame(x = factor("a")))
    Error <rlang_error>
      Can't join on `x$x` x `y$x` because of incompatible types.
      i `x$x` is of type <double>>.
      i `y$x` is of type <factor<4d52a>>>.

