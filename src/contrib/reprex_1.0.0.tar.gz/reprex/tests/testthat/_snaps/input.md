# Leading prompts are removed

    Code
      res2 <- reprex(input = input2, render = FALSE, html_preview = FALSE)
    Message <cliMessage>
      i Removing leading prompts from reprex source.

