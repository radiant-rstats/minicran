



# context("Replacing styles")
# 
# 
# 
# test_that("Replace styles", {
#   
# #   tempFile <- file.path(tempdir(), "temp.xlsx")
# #   wb <- loadWorkbook(file = file.path(path.package("openxlsx"), "loadExample.xlsx"))
# #   
# #   ## create a new style and replace style 2
# #   
# #   newStyle <- createStyle(fgFill = "#FF0000")
# #   
# #   ## replace style 2
# #   getStyles(wb) ## prints styles
# #   replaceStyle(wb, 87, newStyle = newStyle)
# # 
# #   rm(wb)
#   
# })
