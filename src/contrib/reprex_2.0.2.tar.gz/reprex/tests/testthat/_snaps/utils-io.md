# retrofit_files() works

    The `outfile` argument of `reprex()` is deprecated as of reprex 2.0.0.
    Please use the `wd` argument instead.

---

    The `outfile` argument of `reprex()` is deprecated as of reprex 2.0.0.
    Use `reprex(wd = ".")` instead of `reprex(outfile = NA)`.

---

    The `outfile` argument of `reprex()` is deprecated as of reprex 2.0.0.
    * To control output filename, provide a filepath to `input`.
    * Only taking working directory from `outfile`.

---

    The `outfile` argument of `reprex()` is deprecated as of reprex 2.0.0.
    Working directory will be derived from `input`.

---

    The `outfile` argument of `reprex()` is deprecated as of reprex 2.0.0.
    Working directory and output filename will be determined from `input`.

