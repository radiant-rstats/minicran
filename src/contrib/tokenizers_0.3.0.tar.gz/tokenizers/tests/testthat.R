library(testthat)
library(tokenizers)

test_check("tokenizers")
