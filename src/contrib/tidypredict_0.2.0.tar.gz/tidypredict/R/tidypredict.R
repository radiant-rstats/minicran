#' @import rlang
#' @importFrom purrr map2
#' @importFrom purrr map
#' @importFrom purrr map_df
#' @importFrom purrr reduce
#' @import dplyr
#' @import rlang
#' @importFrom tibble tibble
#' @importFrom tibble rowid_to_column
#' @importFrom tibble rownames_to_column
#' @importFrom utils head
#' @importFrom stats predict
#' @importFrom stats qt
#' @import tidyr
#' @import tibble
#' @keywords internal
#'
"_PACKAGE"
NULL
utils::globalVariables(c("."))
