# the dice similarity algorithm is functional

    Code
      get_dice_similarity(graph = graph, nodes = 8:12, direction = "all")
    Condition
      Error in `get_dice_similarity()`:
      ! One or more nodes provided not in graph.

# the Jaccard similarity algorithm is functional

    Code
      get_jaccard_similarity(graph = graph, nodes = 5:7, direction = "away")
    Condition
      Error in `get_jaccard_similarity()`:
      ! `direction` must be one of "all", "in", or "out", not "away".

