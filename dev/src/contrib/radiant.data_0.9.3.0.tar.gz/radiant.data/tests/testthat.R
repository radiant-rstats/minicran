## use shift-cmd-t in Rstudio to run all tests
library(testthat)
test_check("radiant.data")

# testthat::run_examples()
