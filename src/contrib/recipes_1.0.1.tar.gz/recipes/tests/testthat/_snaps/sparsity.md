# bad args

    Code
      bake(rec, new_data = sacr_te, composition = "dgCMatrix")
    Condition
      Error in `convert_matrix()`:
      ! Columns (`beds`, `type`) are not numeric; cannot convert to matrix.

---

    Code
      juice(rec, composition = "dgCMatrix")
    Condition
      Error in `convert_matrix()`:
      ! Columns (`beds`, `type`) are not numeric; cannot convert to matrix.

