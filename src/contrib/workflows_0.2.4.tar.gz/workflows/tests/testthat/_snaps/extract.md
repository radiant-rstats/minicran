# can extract a prepped recipe

    Code
      extract_recipe(workflow, FALSE)
    Error <rlib_error_dots_nonempty>
      `...` is not empty.
      
      We detected these problematic arguments:
      * `..1`
      
      These dots only exist to allow future extensions and should be empty.
      Did you misspecify an argument?

