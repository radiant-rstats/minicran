#ifndef YARDSTICK_H
#define YARDSTICK_H

#define R_NO_REMAP
#include <R.h>
#include <Rinternals.h>

#endif
