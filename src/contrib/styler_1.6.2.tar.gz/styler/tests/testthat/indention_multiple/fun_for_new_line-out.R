function() {
  NULL
}

for (i in 1:3)
{
  2
}
