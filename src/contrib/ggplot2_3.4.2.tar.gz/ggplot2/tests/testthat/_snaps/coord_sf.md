# axis labels can be set manually

    Breaks and labels along x direction are different lengths

---

    Breaks and labels along y direction are different lengths

---

    Graticule labeling format not recognized.

---

    Panel labeling format not recognized.

# default crs works

    Scale limits cannot be mapped onto spatial coordinates in `coord_sf()`
    i Consider setting `lims_method = "geometry_bbox"` or `default_crs = NULL`.

