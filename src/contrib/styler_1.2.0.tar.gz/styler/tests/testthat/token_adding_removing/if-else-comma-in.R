call(
  if (x)
    y,
  if(x)
    z
)

call(if (x) y ,
     if(x) z )

call(if (x) y,
     if(x) z )

call(if (x) y,
     if(x) z)
