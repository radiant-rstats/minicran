#' @export
#' @importFrom ggdist stat_dist_slabinterval
ggdist::stat_dist_slabinterval

#' @export
#' @importFrom ggdist StatDistSlabinterval
ggdist::StatDistSlabinterval

#' @export
#' @importFrom ggdist stat_dist_halfeye
ggdist::stat_dist_halfeye

#' @export
#' @importFrom ggdist stat_dist_eye
ggdist::stat_dist_eye

#' @export
#' @importFrom ggdist stat_dist_ccdfinterval
ggdist::stat_dist_ccdfinterval

#' @export
#' @importFrom ggdist stat_dist_cdfinterval
ggdist::stat_dist_cdfinterval

#' @export
#' @importFrom ggdist stat_dist_gradientinterval
ggdist::stat_dist_gradientinterval

#' @export
#' @importFrom ggdist stat_dist_pointinterval
ggdist::stat_dist_pointinterval

#' @export
#' @importFrom ggdist stat_dist_interval
ggdist::stat_dist_interval

#' @export
#' @importFrom ggdist stat_dist_slab
ggdist::stat_dist_slab
