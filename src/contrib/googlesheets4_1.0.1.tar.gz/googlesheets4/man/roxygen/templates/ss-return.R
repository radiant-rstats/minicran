#' @return The input `ss`, as an instance of [`sheets_id`]
