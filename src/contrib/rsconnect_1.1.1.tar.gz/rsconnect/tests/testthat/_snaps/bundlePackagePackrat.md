# uninstalled packages error

    Code
      snapshotPackratDependencies(app)
    Condition
      Error in `addPackratSnapshot()`:
      ! Failed to snapshot dependencies
      Caused by error:
      ! Unable to retrieve package records for the following packages:
      - 'doesntexist1', 'doesntexist2'

