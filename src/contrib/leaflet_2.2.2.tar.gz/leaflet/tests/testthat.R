library(testthat)
library(leaflet)

test_check("leaflet")
