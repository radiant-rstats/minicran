# generates custom sql

    Code
      sql_table_analyze(con, ident("table"))
    Output
      <SQL> COMPUTE STATS `table`

