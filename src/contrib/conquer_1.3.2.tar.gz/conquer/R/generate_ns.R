#' @useDynLib conquer
#' @importFrom Rcpp evalCpp
#' @importFrom matrixStats rowSds rowQuantiles rowMaxs colSds
#' @importFrom stats qnorm quantile runif
#' @importFrom Matrix rankMatrix
NULL
