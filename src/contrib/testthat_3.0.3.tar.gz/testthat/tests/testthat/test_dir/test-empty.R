test_that("empty test", NULL)

test_that("empty test with error", stop("Argh"))
