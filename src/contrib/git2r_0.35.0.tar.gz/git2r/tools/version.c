#include <git2.h>

#if LIBGIT2_VER_MAJOR < 1
#    error libgit2 version too old
#endif
