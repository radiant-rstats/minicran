## ----setup, include = FALSE---------------------------------------------------
library(tfestimators)
knitr::opts_chunk$set(comment = NA, eval = FALSE)

## -----------------------------------------------------------------------------
#  estimator(
#      model_fn = model_fn,
#      model_dir = "/tmp/test"
#  ) %>% train(input_fn = input, steps = 100L)
#  

