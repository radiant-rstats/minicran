# errors

    Code
      fun()
    Condition
      Error:
      ! Error in a deferred `on.exit()` clause
      Caused by error:
      ! non-numeric argument to binary operator

