# check_bootstrap_version() gives informative error otherwise

    Code
      check_bootstrap_version(1, pkg)
    Condition
      Error:
      ! Boostrap version must be 3 or 5.
      x You set a value of 1 to template.bootstrap in _pkgdown.yml.

