library(testthat)
library(wdman)

# if (identical(tolower(Sys.getenv("NOT_CRAN")), "true")) {
#   test_check("wdman")
# }
