## ---- include=FALSE------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, eval = FALSE, comment = "#>", collapse = TRUE)

## ------------------------------------------------------------------------
#  ## these are fake keys
#  #> create_token(
#  #>   app = "rtweet_token",
#  #>   consumer_key = "XYznzPFOFZR2a39FwWKN1Jp41",
#  #>   consumer_secret = "CtkGEWmSevZqJuKl6HHrBxbCybxI1xGLqrD5ynPd9jG0SoHZbD")
#  # `Error in init_oauth1.0(endpoint, app, permission = params$permission) :
#  #  client error: (401) Unauthorized`

## ------------------------------------------------------------------------
#  ## these are fake keys
#  #> create_token(
#  #>   app = "rtweet_token",
#  #>   consumer_key = "XYznzPFOFZR2a39FwWKN1Jp41",
#  #>   consumer_secret = "CtkGEWmSevZqJuKl6HHrBxbCybxI1xGLqrD5ynPd9jG0SoHZbD")
#  #Error in oauth_listener(authorize_url, is_interactive) :
#  #  httpuv package required to capture OAuth credentials.

## ------------------------------------------------------------------------
#  install.packages("httpuv")

## ------------------------------------------------------------------------
#  #> search_tweets("lang:en")
#  #Warning: 89 - Invalid or expired token.

## ------------------------------------------------------------------------
#  ## these are fake keys
#  #> create_token(
#  #>   app = "rtweet_token",
#  #>   consumer_key = "XYznzPFOFZR2a39FwWKN1Jp41",
#  #>   consumer_secret = "CtkGEWmSevZqJuKl6HHrBxbCybxI1xGLqrD5ynPd9jG0SoHZbD")

