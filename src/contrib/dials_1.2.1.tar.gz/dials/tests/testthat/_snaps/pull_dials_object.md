# pull_dials_object is deprecated

    Code
      pull_dials_object(mod_param, "mixture")
    Condition
      Error:
      ! `pull_dials_object()` was deprecated in dials 0.1.0 and is now defunct.
      i Please use `hardhat::extract_parameter_dials()` instead.

