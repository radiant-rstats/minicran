import scala.util.Try

object Shell {
  def main(args: Array[String]): Unit = {
  }
}
