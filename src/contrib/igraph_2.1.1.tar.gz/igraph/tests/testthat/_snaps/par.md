# print.id in snapshot

    Code
      igraph_opt("print.id")
    Output
      [1] FALSE

# print.id in snapshot (2)

    Code
      igraph_opt("print.id")
    Output
      [1] FALSE

