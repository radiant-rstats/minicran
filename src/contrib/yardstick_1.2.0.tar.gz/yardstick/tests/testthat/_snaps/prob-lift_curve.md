# error handling

    Code
      lift_curve(df, truth, estimate)
    Condition
      Error in `lift_curve()`:
      ! `truth` should be a factor, not a `numeric`.

# errors with class_pred input

    Code
      lift_curve_vec(cp_truth, estimate)
    Condition
      Error in `gain_curve_vec()`:
      ! `truth` should not a `class_pred` object.

