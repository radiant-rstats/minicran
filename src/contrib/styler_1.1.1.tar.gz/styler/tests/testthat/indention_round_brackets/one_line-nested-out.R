a <- xyz(x, 22, if (x > 1) 33 else 4)
