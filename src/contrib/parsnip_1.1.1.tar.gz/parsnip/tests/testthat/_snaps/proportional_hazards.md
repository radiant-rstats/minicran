# updating

    Code
      proportional_hazards() %>% update(penalty = tune())
    Message
      ! parsnip could not locate an implementation for `proportional_hazards` model specifications.
      i The parsnip extension package censored implements support for this specification.
      i Please install (if needed) and load to continue.
    Output
      Proportional Hazards Model Specification (censored regression)
      
      Main Arguments:
        penalty = tune()
      
      Computational engine: survival 
      

