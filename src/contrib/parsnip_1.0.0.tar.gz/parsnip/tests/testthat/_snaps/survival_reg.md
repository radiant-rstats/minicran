# updating

    Code
      survival_reg() %>% update(dist = "lnorm")
    Message
      parsnip could not locate an implementation for `survival_reg` censored regression model specifications using the `survival` engine.
      i The parsnip extension package censored implements support for this specification.
      i Please install (if needed) and load to continue.
    Output
      Parametric Survival Regression Model Specification (censored regression)
      
      Main Arguments:
        dist = lnorm
      
      Computational engine: survival 
      

