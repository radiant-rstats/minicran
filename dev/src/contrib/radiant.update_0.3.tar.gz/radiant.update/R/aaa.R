globalVariables(".rs.restartR")

#' radiant.update
#'
#' @name radiant.update
#' @docType package
#' @importFrom import from
#' @importFrom utils new.packages available.packages installed.packages compareVersion
#' @importFrom methods is
#'
NULL
