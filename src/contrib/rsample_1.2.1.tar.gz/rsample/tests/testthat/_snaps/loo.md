# printing

    Code
      loo_cv(dat1)
    Output
      # Leave-one-out cross-validation 
      # A tibble: 20 x 2
         splits         id        
         <list>         <chr>     
       1 <split [19/1]> Resample1 
       2 <split [19/1]> Resample2 
       3 <split [19/1]> Resample3 
       4 <split [19/1]> Resample4 
       5 <split [19/1]> Resample5 
       6 <split [19/1]> Resample6 
       7 <split [19/1]> Resample7 
       8 <split [19/1]> Resample8 
       9 <split [19/1]> Resample9 
      10 <split [19/1]> Resample10
      11 <split [19/1]> Resample11
      12 <split [19/1]> Resample12
      13 <split [19/1]> Resample13
      14 <split [19/1]> Resample14
      15 <split [19/1]> Resample15
      16 <split [19/1]> Resample16
      17 <split [19/1]> Resample17
      18 <split [19/1]> Resample18
      19 <split [19/1]> Resample19
      20 <split [19/1]> Resample20

