# Version 1.1-1 (development, rev. 381-382)

* Upgrade **spatstat**-family reverse dependencies


# Version 1.0-2 (2020-08-24, rev. 371-380)

* New `as.im.RasterLayer()` version

* Update stored **sp** objects

# Version 1.0-1 (2020-05-14, rev. -370)

* Update for `linnet` coercion methods

* Added read support for (very) legacy MAP objects