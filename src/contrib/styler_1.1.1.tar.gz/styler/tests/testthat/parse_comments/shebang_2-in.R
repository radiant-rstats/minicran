#!/usr/bin/env Rscript
#!/usr/bin/env Rscript
a <- 3

#!/usr/bin /env Rscript -m --set "W"
dd <- 33
#!/usr/bin\ /env Rscript -m --set "W"
c()
#!NEED TO REMOVE THIS
