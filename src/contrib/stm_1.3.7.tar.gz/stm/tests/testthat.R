library(testthat)
library(stm)

test_check("stm")
