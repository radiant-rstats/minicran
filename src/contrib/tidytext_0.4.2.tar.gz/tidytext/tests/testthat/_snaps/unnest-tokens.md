# tokenizing errors with appropriate error message

    Token must be a supported type, or a function that takes a character vector as input
    i Did you mean `token = "words"`?

# unnest_tokens raises an error if custom tokenizer gives bad output

    Expected output of tokenizing function to be a list of length 1

---

    Expected output of tokenizing function to be a list of length 1

# tokenizing tweets is deprecated

    Support for `token = "tweets"` was deprecated in tidytext 0.4.0 and is now defunct.

