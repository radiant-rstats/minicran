# rle 1.0

Initial release, split out of the `statnet.common` package.
