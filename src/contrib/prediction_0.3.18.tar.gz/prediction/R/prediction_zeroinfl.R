#' @rdname prediction
#' @export
prediction.zeroinfl <- prediction.hurdle
