summaryFull <-
function (object, ...) 
UseMethod("summaryFull")
