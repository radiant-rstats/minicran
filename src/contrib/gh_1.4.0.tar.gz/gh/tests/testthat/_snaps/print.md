# can print all types of object

    Code
      json
    Output
      {
        "name": "LICENSE",
        "path": "LICENSE",
        "sha": "c71242092c79fcc895841ca3e7de5bbcc551cde5",
        "size": 81,
        "url": "https://api.github.com/repos/r-lib/gh/contents/LICENSE?ref=v1.2.0",
        "html_url": "https://github.com/r-lib/gh/blob/v1.2.0/LICENSE",
        "git_url": "https://api.github.com/repos/r-lib/gh/git/blobs/c71242092c79fcc895841ca3e7de5bbcc551cde5",
        "download_url": "https://raw.githubusercontent.com/r-lib/gh/v1.2.0/LICENSE",
        "type": "file",
        "content": "WUVBUjogMjAxNS0yMDIwCkNPUFlSSUdIVCBIT0xERVI6IEfDoWJvciBDc8Oh\ncmRpLCBKZW5uaWZlciBCcnlhbiwgSGFkbGV5IFdpY2toYW0K\n",
        "encoding": "base64",
        "_links": {
          "self": "https://api.github.com/repos/r-lib/gh/contents/LICENSE?ref=v1.2.0",
          "git": "https://api.github.com/repos/r-lib/gh/git/blobs/c71242092c79fcc895841ca3e7de5bbcc551cde5",
          "html": "https://github.com/r-lib/gh/blob/v1.2.0/LICENSE"
        }
      } 
    Code
      file
    Output
      [1] "LICENSE"
      attr(,"class")
      [1] "gh_response" "path"       
    Code
      raw
    Output
       [1] 59 45 41 52 3a 20 32 30 31 35 2d 32 30 32 30 0a 43 4f 50 59 52 49 47 48 54
      [26] 20 48 4f 4c 44 45 52 3a 20 47 c3 a1 62 6f 72 20 43 73 c3 a1 72 64 69 2c 20
      [51] 4a 65 6e 6e 69 66 65 72 20 42 72 79 61 6e 2c 20 48 61 64 6c 65 79 20 57 69
      [76] 63 6b 68 61 6d 0a
      attr(,"class")
      [1] "gh_response" "raw"        

