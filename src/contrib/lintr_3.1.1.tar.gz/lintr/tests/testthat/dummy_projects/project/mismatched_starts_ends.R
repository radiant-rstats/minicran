#nolint end

#nolint start

c(1,2)

#nolint start

#nolint end

#nolint start
