
/* bilinear: */
extern void F77_NAME(biliip) (double *x0, double *y0, double *z0,
                      int *n0, double *x, double *y, double *z,
                      int *nx, int *ny, int *ier);
