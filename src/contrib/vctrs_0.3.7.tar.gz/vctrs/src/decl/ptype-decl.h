#ifndef VCTRS_PTYPE_DECL_H
#define VCTRS_PTYPE_DECL_H

static inline SEXP vec_ptype_method(SEXP x);
static inline SEXP vec_ptype_invoke(SEXP x, SEXP method);

#endif
