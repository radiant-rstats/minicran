library(testthat)
library(rgexf)

test_check("rgexf")
