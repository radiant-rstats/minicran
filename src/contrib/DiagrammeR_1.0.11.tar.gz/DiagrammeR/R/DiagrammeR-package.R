#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import rlang
#' @import htmlwidgets
#' @import RColorBrewer
#' @import glue
#' @importFrom magrittr not
#' @import visNetwork
## usethis namespace: end
NULL
