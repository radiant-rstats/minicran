# nocov start

# Global vars ------------------------------------------------------------------

utils::globalVariables(c(
  "contrast", "difference", "model_1", "model_2",
  ".", "aes", "posterior", ".metric",
  "id", "model", "splits", "statistic", "Resample",
  ".config", ".estimate", ".lower", ".upper",
  "pract_equiv", "sub_model", "wflow_id", "workflow"
))

# nocov end
