

test_that("hi there", {
  I(am(a(package(x))))
})
