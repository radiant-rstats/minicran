#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom utils installed.packages
#' @import rlang
#' @import fs
## usethis namespace: end
NULL

release_bullets <- function() {
  c(
    "Check that [test/widget.html](https://pkgdown.r-lib.org/dev/articles/) responds to mouse clicks on 5/10/50"
  )
}
