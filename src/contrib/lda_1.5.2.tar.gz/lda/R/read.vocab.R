read.vocab <-
function (filename = "vocab.dat") 
{
    readLines(filename)
}
