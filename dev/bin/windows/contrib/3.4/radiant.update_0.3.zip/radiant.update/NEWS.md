# radiant.update

Contains one function that updates Radiant and all required packages. The function will restart the R-session in Rstudio and run the command below:

source("https://raw.githubusercontent.com/radiant-rstats/minicran/gh-pages/update.R")

