hello <- function() {
  gettext("Hello", domain = "R-testTranslations")
}
