library(testthat)
library(workflowsets)

test_check("workflowsets")
