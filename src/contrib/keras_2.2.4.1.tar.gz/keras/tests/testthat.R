library(testthat)
library(keras)

test_check("keras")
