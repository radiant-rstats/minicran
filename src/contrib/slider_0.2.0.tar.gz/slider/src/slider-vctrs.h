#ifndef SLIDER_VCTRS_H
#define SLIDER_VCTRS_H

#include "slider-vctrs-public.h"
#include "slider-vctrs-private.h"

#endif
