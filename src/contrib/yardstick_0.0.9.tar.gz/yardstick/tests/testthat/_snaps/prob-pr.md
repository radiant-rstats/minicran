# PR - zero row data frame works

    Code
      out <- pr_curve(df, y, x)
    Warning <simpleWarning>
      There are `0` event cases in `truth`, results will be meaningless.

