{
  if (TRUE)
    3
  else
    4
}

{
  if (TRUE) {
    3
  } else
    4
}

{
  if (TRUE)
    3
  else {
    4
  }
}

{
  if (TRUE) {
    3
  } else {
    4
  }
}
