# No sensitive to decimal option

    Code
      style_text("1")
    Output
      1

