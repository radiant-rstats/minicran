# can construct and print

    Code
      in_schema("schema", "table")
    Output
      <SCHEMA> `schema`.`table`

