# write_parquet() with invalid input type

    Object must be coercible to an Arrow Table using `as_arrow_table()`
    Caused by error in `as_arrow_table()`:
    ! No method for `as_arrow_table()` for object of class Array / ArrowDatum / ArrowObject / R6

