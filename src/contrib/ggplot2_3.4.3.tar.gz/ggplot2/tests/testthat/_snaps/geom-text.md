# geom_text() checks input

    both `position` and `nudge_x`/`nudge_y` are supplied
    i Only use one approach to alter the position

