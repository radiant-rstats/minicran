# `future_options()` is hard deprecated

    Code
      future_options()
    Condition
      Error:
      ! `future_options()` was deprecated in furrr 0.3.0 and is now defunct.
      Please use `furrr_options()` instead.

