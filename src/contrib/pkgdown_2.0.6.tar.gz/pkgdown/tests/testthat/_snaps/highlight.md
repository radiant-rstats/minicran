# pre() can produce needed range of outputs

    Code
      cat(pre("x"))
    Output
      <pre><code>x</code></pre>
    Code
      cat(pre("x", r_code = TRUE))
    Output
      <pre class='sourceCode r'><code>x</code></pre>

