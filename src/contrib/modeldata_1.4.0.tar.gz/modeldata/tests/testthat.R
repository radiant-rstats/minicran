library(testthat)
library(modeldata)

test_check("modeldata")
