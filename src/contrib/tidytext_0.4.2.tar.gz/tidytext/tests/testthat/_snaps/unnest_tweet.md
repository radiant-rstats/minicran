# unnest_tweet works

    `unnest_tweets()` was deprecated in tidytext 0.4.0 and is now defunct.

