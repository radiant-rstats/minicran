#pragma once

struct InternalParamsExp
{   
    double sml;
    double eps;
    double big;
    int mnlam;
    double rsqmax;
    double pmin;
    double exmx;
    int itrace;
};
