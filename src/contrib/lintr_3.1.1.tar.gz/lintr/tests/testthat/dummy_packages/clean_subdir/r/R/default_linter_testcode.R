f <- function(x, y = 1) x + y
message("hello")
y <- 2 + (1:10)
