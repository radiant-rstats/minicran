#' @export
#' @importFrom ggdist stat_sample_slabinterval
ggdist::stat_sample_slabinterval

#' @export
#' @importFrom ggdist StatSampleSlabinterval
ggdist::StatSampleSlabinterval

#' @export
#' @importFrom ggdist stat_halfeye
ggdist::stat_halfeye

#' @export
#' @importFrom ggdist stat_eye
ggdist::stat_eye

#' @export
#' @importFrom ggdist stat_ccdfinterval
ggdist::stat_ccdfinterval

#' @export
#' @importFrom ggdist stat_cdfinterval
ggdist::stat_cdfinterval

#' @export
#' @importFrom ggdist stat_gradientinterval
ggdist::stat_gradientinterval

#' @export
#' @importFrom ggdist stat_histinterval
ggdist::stat_histinterval

#' @export
#' @importFrom ggdist stat_slab
ggdist::stat_slab
