#' @importFrom methods setOldClass
setOldClass("xml_document")
setOldClass("xml_missing")
setOldClass("xml_node")
setOldClass("xml_nodeset")
