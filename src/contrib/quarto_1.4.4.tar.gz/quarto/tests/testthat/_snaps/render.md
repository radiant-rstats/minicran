# quarto_args in quarto_render

    Code
      quarto_render("input.qmd", quiet = TRUE, quarto_args = c("--to", "native"))
    Output
      Running <quarto full path> render input.qmd --quiet --to native

