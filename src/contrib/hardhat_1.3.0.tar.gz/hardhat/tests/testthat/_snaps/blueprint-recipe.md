# `recipe` argument is validated

    Code
      new_recipe_blueprint(recipe = 1)
    Condition
      Error in `new_recipe_blueprint()`:
      ! `recipe` must be a recipe or `NULL`, not the number 1.

