## ----include=FALSE------------------------------------------------------------
options(width = 80)
knitr::opts_chunk$set(comment = '#>')

## ----echo=FALSE---------------------------------------------------------------
knitr::kable(head(mtcars, 4))

