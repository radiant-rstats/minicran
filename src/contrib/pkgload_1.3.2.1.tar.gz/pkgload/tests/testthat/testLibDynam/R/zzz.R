.onLoad <- function(lib, pkg){
  library.dynam("testDllLoad", pkg, lib)

}
