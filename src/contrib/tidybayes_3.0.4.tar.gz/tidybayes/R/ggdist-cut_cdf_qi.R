#' @export
#' @importFrom ggdist cut_cdf_qi
ggdist::cut_cdf_qi
