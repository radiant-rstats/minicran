# combined bytes are aligned

    Code
      new_bytes(c(400, 4e+05))
    Output
      *  400 B
      * 400 kB

