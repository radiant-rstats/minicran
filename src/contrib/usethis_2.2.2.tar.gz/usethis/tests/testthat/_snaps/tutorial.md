# use_tutorial() checks its inputs

    Code
      use_tutorial()
    Condition
      Error in `use_tutorial()`:
      ! `name` must be a valid name, not absent.

---

    Code
      use_tutorial(name = "tutorial-file")
    Condition
      Error in `use_tutorial()`:
      ! `title` must be a valid name, not absent.

