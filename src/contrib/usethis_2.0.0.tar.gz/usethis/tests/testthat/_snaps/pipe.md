# use_pipe(export = FALSE) gives advice if no package doc

    Code
      use_pipe(export = FALSE)
    Message <message>
      v Adding 'magrittr' to Imports field in DESCRIPTION
    Message <message>
      * Copy and paste this line into some roxygen header, then run `devtools::document()`:
    Message <message>
        #' @importFrom magrittr %>%
    Message <message>
      * Alternative recommendation: call `use_package_doc()`, then call `use_pipe()` again.

