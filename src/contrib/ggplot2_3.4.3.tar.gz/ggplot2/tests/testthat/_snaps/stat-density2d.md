# stat_density2d can produce contour and raster data

    Problem while computing stat.
    i Error occurred in the 1st layer.
    Caused by error in `compute_layer()`:
    ! Invalid value of `contour_var` ("abcd")
    i Supported values are "density", "ndensity", and "count".

