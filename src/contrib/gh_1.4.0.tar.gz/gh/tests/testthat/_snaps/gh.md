# generates a useful message

    Code
      gh("/missing")
    Condition
      Error in `gh()`:
      ! GitHub API error (404): Not Found
      x URL not found: <https://api.github.com/missing>
      i Read more at <https://docs.github.com/rest>

