RcppRoll
========

[![CRAN status](https://www.r-pkg.org/badges/version/RcppRoll)](https://cran.r-project.org/package=RcppRoll)

This package provides windowed-versions of commonly-used mathematical
and statistical functions.

Install the latest release from CRAN with:

    install.packages("RcppRoll")

Or, install the development version with:

    install_github("kevinushey/RcppRoll")
