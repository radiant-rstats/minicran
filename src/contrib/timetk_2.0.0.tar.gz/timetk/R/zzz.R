.onLoad = function(libname, pkgname) {
    options(
        tk_time_scale_template = tk_time_scale_template()
    )
}
