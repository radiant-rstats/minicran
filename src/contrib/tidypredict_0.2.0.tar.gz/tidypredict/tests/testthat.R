library(testthat)
library(tidypredict)

test_check("tidypredict")