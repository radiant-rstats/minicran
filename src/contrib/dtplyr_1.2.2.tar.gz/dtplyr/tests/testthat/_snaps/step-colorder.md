# can handle duplicate column names

    The column(s) x do not uniquely match a column in `x`.

# checks col_order

    Every element of `col_order` must be unique.

---

    Every element of `col_order` must be unique.

