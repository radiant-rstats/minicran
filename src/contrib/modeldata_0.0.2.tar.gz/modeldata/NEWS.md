# modeldata 0.0.2

* The bivariate dataset was missing, this has been corrected (@mdogucu, #5).

* The [Ames](https://github.com/topepo/AmesHousing) and [penguin](https://github.com/allisonhorst/palmerpenguins) data sets were added. 

# modeldata 0.0.1

* Added a `NEWS.md` file to track changes to the package.
