library(testthat)
library(rsample)

test_check(package = "rsample")
q("no")

