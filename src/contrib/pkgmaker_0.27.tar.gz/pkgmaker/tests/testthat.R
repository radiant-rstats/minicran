library(testthat)
library(pkgmaker)

test_check("pkgmaker")
