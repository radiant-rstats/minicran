# work with class_pred input

    Code
      mcc_vec(cp_truth, cp_estimate)
    Condition
      Error in `mcc_vec()`:
      ! `truth` should not a <class_pred> object.

