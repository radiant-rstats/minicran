# work with class_pred input

    Code
      accuracy_vec(cp_truth, cp_estimate)
    Condition
      Error in `accuracy_vec()`:
      ! `truth` should not a <class_pred> object.

