# can construct and print vertical

    Code
      construct_vertical(c("1 + 1", "nw"))
    Output
      1 + 1
      nw

# can lookup tokens

    Code
      lookup_new_special()
    Output
      [1] "SPECIAL-PIPE"  "SPECIAL-IN"    "SPECIAL-OTHER"

