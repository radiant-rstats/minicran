# collections API has been deprecated

    Code
      lookup_collections("custom-539487832448843776")
    Condition
      Error:
      ! `lookup_collections()` was deprecated in rtweet 1.0.0 and is now defunct.
    Code
      get_collections(status_id = "925172982313570306")
    Condition
      Error:
      ! `get_collections()` was deprecated in rtweet 1.0.0 and is now defunct.

