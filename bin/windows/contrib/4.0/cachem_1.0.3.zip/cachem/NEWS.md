cachem 1.0.3
============

* Addressed issues with timing-sensitive tests.

cachem 1.0.2
============

* Closed #4: Sped up pruning for `cache_mem`. (#5)

* Fixed `cache_mem` pruning with `evict="lru"`.

cachem 1.0.1
============

* Fixed function declaration of `C_validate_key`.

cachem 1.0.0
============

* First CRAN release.
