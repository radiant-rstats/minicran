

#' @importFrom stats na.omit setNames
#' @importFrom utils available.packages installed.packages contrib.url file_test formatUL getFromNamespace glob2rx packageVersion read.csv
NULL
