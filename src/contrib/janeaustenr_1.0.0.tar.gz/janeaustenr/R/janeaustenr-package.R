#' @keywords internal
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL

globalVariables(c("sensesensibility", "prideprejudice", "mansfieldpark", 
                  "emma", "northangerabbey", "persuasion", "book"))

