# pillar methods are available for units objects

    Code
      pillar::pillar(x[1])
    Output
      <pillar>
      [km]
         1
    Code
      pillar::pillar(m[1])
    Output
      <pillar>
      <mixed_units>
             1 [km]

