# throws error if environment.py fails

    Code
      inferPythonEnv(".", pythonPathOrSkip())
    Condition
      Error in `inferPythonEnv()`:
      ! Error reading requirements.txt: [Errno 13] Permission denied: './requirements.txt'

