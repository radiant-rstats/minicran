#' #' @name gexf-methods
#' #' @export
#' plot.gexf <- function(x, EdgeType=NULL, output.dir=NULL,...){  
#'   # WIP
#' 
#'   .Defunct("Gephi for visualizing")  
#' }
#' 
