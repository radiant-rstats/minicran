# renames src/ files

    Code
      rename_files("foo", "bar")
    Message
      v Moving 'src/foo.c', 'src/foo.h' to 'src/bar.c', 'src/bar.h'

