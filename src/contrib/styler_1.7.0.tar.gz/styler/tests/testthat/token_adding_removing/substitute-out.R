expr <- substitute(airquality %>% FUN_EXPR, env = list(FUN_EXPR = call("FUN_head")))
a %>%
  x()
