library(testthat)
test_check("Quandl")
