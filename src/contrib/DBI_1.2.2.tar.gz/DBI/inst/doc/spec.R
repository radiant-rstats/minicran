## ----echo = FALSE-------------------------------------------------------------
knitr::asis_output(paste(readLines("spec.md"), collapse = "\n"))

