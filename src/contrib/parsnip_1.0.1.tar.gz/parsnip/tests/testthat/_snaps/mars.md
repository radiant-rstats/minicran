# updating

    Code
      expr1 %>% update(num_terms = tune(), nk = tune())
    Output
      MARS Model Specification (unknown)
      
      Main Arguments:
        num_terms = tune()
      
      Engine-Specific Arguments:
        nk = tune()
      
      Computational engine: earth 
      

