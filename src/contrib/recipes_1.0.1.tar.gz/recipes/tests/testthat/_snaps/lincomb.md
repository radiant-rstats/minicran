# printing

    Code
      print(dum_filtered)
    Output
      Recipe
      
      Inputs:
      
            role #variables
         outcome          1
       predictor         12
      
      Operations:
      
      Linear combination filter on all_predictors()

---

    Code
      prep(dum_filtered)
    Output
      Recipe
      
      Inputs:
      
            role #variables
         outcome          1
       predictor         12
      
      Training data contained 24 data points and no missing data.
      
      Operations:
      
      Linear combination filter removed N1, P1, K1 [trained]

# empty printing

    Code
      rec
    Output
      Recipe
      
      Inputs:
      
            role #variables
         outcome          1
       predictor         10
      
      Operations:
      
      Linear combination filter on <none>

---

    Code
      rec
    Output
      Recipe
      
      Inputs:
      
            role #variables
         outcome          1
       predictor         10
      
      Training data contained 32 data points and no missing data.
      
      Operations:
      
      Linear combination filter removed <none> [trained]

