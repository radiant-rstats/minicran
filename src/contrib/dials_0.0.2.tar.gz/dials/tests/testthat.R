library(testthat)
library(dials)

test_check("dials")
