# not marginal plot with grid search

    Code
      autoplot(knn_results, type = "performance")
    Error <rlang_error>
      `type = performance` is only used iterative search results.

---

    Code
      autoplot(knn_results, type = "parameters")
    Error <rlang_error>
      `type = parameters` is only used iterative search results.

# coord_obs_pred

    Removed 1 rows containing missing values (geom_point).

