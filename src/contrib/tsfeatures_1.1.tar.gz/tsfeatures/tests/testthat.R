library(testthat)
library(tsfeatures)

test_check("tsfeatures")
