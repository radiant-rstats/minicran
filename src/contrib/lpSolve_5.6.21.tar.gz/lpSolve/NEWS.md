# lpSolve 5.6.21

* Added a `NEWS.md` file to track changes to the package.

* lpSolve now compiles on OpenBSD (#21).

