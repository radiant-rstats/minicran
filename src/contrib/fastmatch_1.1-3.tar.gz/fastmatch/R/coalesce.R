coalesce <- function(x) .Call(C_coalesce, x)
