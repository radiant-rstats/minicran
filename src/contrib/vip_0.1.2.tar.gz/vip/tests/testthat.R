library(testthat)
library(vip)

test_check("vip")
