# `pull_workflow_preprocessor()` is soft-deprecated

    Code
      x <- pull_workflow_preprocessor(workflow)
    Warning <lifecycle_warning_deprecated>
      `pull_workflow_preprocessor()` was deprecated in workflows 0.2.3.
      Please use `extract_preprocessor()` instead.

# `pull_workflow_spec()` is soft-deprecated

    Code
      x <- pull_workflow_spec(workflow)
    Warning <lifecycle_warning_deprecated>
      `pull_workflow_spec()` was deprecated in workflows 0.2.3.
      Please use `extract_spec_parsnip()` instead.

# `pull_workflow_fit()` is soft-deprecated

    Code
      x <- pull_workflow_fit(workflow)
    Warning <lifecycle_warning_deprecated>
      `pull_workflow_fit()` was deprecated in workflows 0.2.3.
      Please use `extract_fit_parsnip()` instead.

# `pull_workflow_mold()` is soft-deprecated

    Code
      x <- pull_workflow_mold(workflow)
    Warning <lifecycle_warning_deprecated>
      `pull_workflow_mold()` was deprecated in workflows 0.2.3.
      Please use `extract_mold()` instead.

# `pull_workflow_prepped_recipe()` is soft-deprecated

    Code
      x <- pull_workflow_prepped_recipe(workflow)
    Warning <lifecycle_warning_deprecated>
      `pull_workflow_prepped_recipe()` was deprecated in workflows 0.2.3.
      Please use `extract_recipe()` instead.

