if (getRversion() < "3.5.0") {
  isFALSE <- function(x) identical(x, FALSE)
}
