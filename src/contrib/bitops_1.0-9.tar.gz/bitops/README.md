# R-bitops -- R CRAN package `bitops` -- implementing bitwise operations

## Functionality

Bitwise operations on (the 32-bit) \R integers

## Context and History

Probably the smallest [CRAN](https://CRAN.R-project.org)
[R](https://www.r-project.org) package I maintain,
the package has a long history, originating as S / S-plus extensions by
Steve Dutky.

I got involved for the first time around 2004, and later became maintainer
as Steve had moved on, and other CRAN packages depended on `bitops`,
see [bitops on CRAN](https://CRAN.R-project.org/package=bitops).
