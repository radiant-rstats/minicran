library(testthat)
library(GPfit)

test_check("GPfit", reporter = "summary")
