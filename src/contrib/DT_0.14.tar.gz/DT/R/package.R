#' @importFrom htmlwidgets JS saveWidget
#' @export JS saveWidget
#' @importFrom magrittr %>%
#' @export %>%
#' @import stats utils
NULL

DataTablesVersion = '1.10.20'
