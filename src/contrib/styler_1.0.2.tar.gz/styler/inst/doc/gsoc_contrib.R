#s#------------------------------------------------------------------------
knitr::opts_chunk$set(eval= FALSE)

#s#------------------------------------------------------------------------
#s library("gitsum")
#s library("tidyverse")
#s log <- git_log_detailed() %>%
#s   filter(date > as.Date("2017-06-01"), date < as.Date("2017-08-31"))

#s#------------------------------------------------------------------------
#s log %>%
#s   group_by(author_name) %>%
#s   count()
