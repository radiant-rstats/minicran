#' randomizr
#' 
#' Easy-to-Use Tools for Common Forms of Random Assignment and Sampling
#'
#' @name randomizr
#' @docType package
NULL
