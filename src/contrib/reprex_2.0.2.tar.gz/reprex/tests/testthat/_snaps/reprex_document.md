# ad responds to venue

    Code
      ad("gh")
    Output
      <sup>Created on `r Sys.Date()` with [reprex v`r utils::packageVersion("reprex")`](https://reprex.tidyverse.org)</sup>

---

    Code
      ad("slack")
    Output
      Created on `r Sys.Date()` with [reprex v`r utils::packageVersion("reprex")`](https://reprex.tidyverse.org)

---

    Code
      ad("r")
    Output
      Created on `r Sys.Date()` with reprex v`r utils::packageVersion("reprex")` https://reprex.tidyverse.org

