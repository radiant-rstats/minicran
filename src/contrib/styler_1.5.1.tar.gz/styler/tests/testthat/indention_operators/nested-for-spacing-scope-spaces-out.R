for (x in 1) {
  x
  for (x in k)
    3
}

for (x in 1) {
  x
  for (x in k)
  3
}
