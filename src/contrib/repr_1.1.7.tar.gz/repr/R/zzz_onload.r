.onLoad <- function(libname = NULL, pkgname = NULL) {
	onload_chars()
	onload_options()
}
