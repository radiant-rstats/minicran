"psych" <-
function () {} # a dummy function to make it appear in the help menu

