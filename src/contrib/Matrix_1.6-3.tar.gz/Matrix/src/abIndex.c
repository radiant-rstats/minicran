#include "Mdefines.h"
#include "abIndex.h"

#define _rle_d_
#include "t_Matrix_rle.c"
#undef _rle_d_

#define _rle_i_
#include "t_Matrix_rle.c"
#undef _rle_i_
