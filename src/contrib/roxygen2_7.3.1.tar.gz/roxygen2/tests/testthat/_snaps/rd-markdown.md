# @title warns about multiple paragraphs

    Code
      . <- roc_proc_text(rd_roclet(), block)
    Message
      x <text>:2: @title must be a single paragraph.

