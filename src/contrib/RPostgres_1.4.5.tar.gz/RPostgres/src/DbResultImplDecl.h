class PqResultImpl;
typedef PqResultImpl DbResultImpl;
