myfunc <- function(x) {
  x + 1
}
