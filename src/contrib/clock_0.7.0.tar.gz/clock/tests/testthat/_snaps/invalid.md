# errors on unsupported types

    Code
      invalid_remove(1)
    Condition
      Error in `invalid_remove()`:
      ! Can't perform this operation on a <numeric>.

