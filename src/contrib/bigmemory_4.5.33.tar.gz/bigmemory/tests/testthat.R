library(testthat)
library(bigmemory)

test_check("bigmemory")
