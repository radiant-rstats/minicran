/* include R header files */

#define STRICT_R_HEADERS
#include <R.h>
#include <Rinternals.h>
