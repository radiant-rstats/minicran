#' @docType package
#' @keywords internal
"_PACKAGE"

#' @import DBI
NULL

#' @import methods
NULL

#' @importFrom R6 R6Class
NULL

#' @importFrom later later
NULL
