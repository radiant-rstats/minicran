$xy
<SQL>
SELECT `x` * 2.0 AS `x`, `y` * 2.0 AS `y`
FROM `df`

$yx
<SQL>
SELECT `y` * 2.0 AS `y`, `x` * 2.0 AS `x`
FROM `df`

