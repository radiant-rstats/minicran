.onLoad <- function(...) {
  dbplyr_register_methods()
}
