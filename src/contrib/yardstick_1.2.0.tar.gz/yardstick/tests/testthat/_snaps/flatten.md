# flat tables

    Code
      yardstick:::flatten(three_class_tb[, 1:2])
    Condition
      Error in `yardstick:::flatten()`:
      ! table must have equal dimensions

