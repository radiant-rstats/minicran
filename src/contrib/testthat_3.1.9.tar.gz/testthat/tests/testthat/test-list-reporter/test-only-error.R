stop('dying outside of tests')
