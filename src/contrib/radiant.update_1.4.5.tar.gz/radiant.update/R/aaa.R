globalVariables(".rs.restartR")

#' radiant.update
#'
#' @name radiant.update
#' @docType package
#' @importFrom utils new.packages old.packages available.packages installed.packages compareVersion sessionInfo remove.packages
#'
NULL
