library(testthat)

# Import should never be attached
#library(import)

test_check("import")
