a <- function() {
     bbx
  x
}
