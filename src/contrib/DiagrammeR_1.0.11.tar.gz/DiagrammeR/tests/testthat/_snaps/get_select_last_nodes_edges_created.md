# getting or selecting the last nodes created is possible

    Code
      get_last_nodes_created(graph_node_deleted)
    Condition
      Error in `get_last_nodes_created()`:
      ! The previous graph transformation function resulted in a removal of nodes.
    Code
      select_last_nodes_created(graph_node_deleted)
    Condition
      Error in `select_last_nodes_created()`:
      ! The previous graph transformation function resulted in a removal of nodes.

