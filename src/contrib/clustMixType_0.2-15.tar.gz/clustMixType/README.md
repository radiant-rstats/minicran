# R Package clustMixType

k-Prototypes Clustering for Mixed Variable-Type Data. For details cf. [R Journal paper](https://journal.r-project.org/archive/2018/RJ-2018-048/index.html).