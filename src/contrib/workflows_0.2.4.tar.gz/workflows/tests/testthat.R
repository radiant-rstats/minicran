library(testthat)
library(workflows)

test_check("workflows")
