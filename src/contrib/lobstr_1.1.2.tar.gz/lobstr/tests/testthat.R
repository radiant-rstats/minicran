library(testthat)
library(lobstr)

test_check("lobstr")
