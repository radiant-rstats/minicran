## use shift-cmd-t to run all tests
library(testthat)
test_check("radiant.update")
