#' Deprecated Functions
#' @name deprecated
#' @param ... anything

#' @export
#' @rdname deprecated
Deque <- function(...) {
    deque(...)
}

#' @export
#' @rdname deprecated
Dict <- function(...) {
    dict(...)
}

#' @export
#' @rdname deprecated
OrderedDict <- function(...) {
    ordered_dict(...)
}

#' @export
#' @rdname deprecated
PriorityQueue <- function(...) {
    priority_queue(...)
}

#' @export
#' @rdname deprecated
Queue <- function(...) {
    queue(...)
}

#' @export
#' @rdname deprecated
Stack <- function(...) {
    stack(...)
}
