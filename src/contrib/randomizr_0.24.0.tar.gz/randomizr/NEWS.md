# randomizr 0.24.0

* Documentation fix

# randomizr 0.22.0

* Added a `NEWS.md` file to track changes to the package.
* Removed suggests dependency of blockTools per Prof. Ripley email (the package was removed from CRAN)
* Added Graeme Blair as a contributor
* Small bug fixes
* Added permutation support for random sampling functions

