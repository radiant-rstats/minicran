# tidymodels 0.1.1

 * Updated versions
 
 * `tidyposterior`, `pillar`, `tidypredict`, `tidytext` were removed from the imports list due to an `R CMD check` warning about the number of imports.  
 
 * `tidyr` and `modeldata` were added to the imports list. 

# tidymodels 0.0.4

 * Updated versions

 * Added `workflows`, and `tune` to the core package list. 

 * Moved away from testing via `travis`

# tidymodels 0.0.3

 * Updated versions

# tidymodels 0.0.2

 * Added  `parsnip` and `dials` to the core package list. 

 * Package requirements bumped to current versions.


# tidymodels 0.0.1

First CRAN version.



