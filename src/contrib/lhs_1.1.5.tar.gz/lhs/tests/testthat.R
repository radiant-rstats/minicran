library(testthat)
library(lhs)

test_check("lhs")
