library(testthat)
library(gitcreds)

test_check("gitcreds", reporter = "progress")
