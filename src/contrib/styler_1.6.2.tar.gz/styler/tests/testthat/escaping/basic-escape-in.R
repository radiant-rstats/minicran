#' things
#'
#' @examples
#' call("\\.")
NULL


#' things
#'
#' @examples
#' call("\n")
NULL

#' things
#'
#' @examples
#' call("\n")
#' ano("\\.", further = X)
NULL


#' things
#'
#' @examples
#' call('\n')
#' ano("\\.", further = X)
NULL

'single quotes with
embedded and \n not embedded line breaks'

x <- '	2' # there is a tab emebbed (created with writeLines("x <- '\t2'"))

x <- '\001'
'\x01'

"\01"
'\01'

#' things
#'
#' @examplesIf N
#' call("\n")
#' ano("\\.", further = X)
NULL

#' things
#'
#' @examplesIf call("\n")
#' ano("\\.", further = X)
NULL
