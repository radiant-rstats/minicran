# gh_make_request() errors if unknown verb

    Unknown HTTP verb: "GEEET"

