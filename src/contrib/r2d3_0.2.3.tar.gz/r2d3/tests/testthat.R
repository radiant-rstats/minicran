library(testthat)
library(r2d3)

test_check("r2d3")
