library(testthat)
suppressPackageStartupMessages(library(sf))
suppressPackageStartupMessages(library(lwgeom))

test_check("lwgeom")
