# styler: off
aflh({
  isfris %>%
    # comment
    tjnfaxasf12af7987A() %>% # comment
    tjnfaxdfaasfaf7987A() %>%
    tjnfxasfaf798fA() %>%
    tf797A() %>% # more
    # comment
    yyexprzB()
})
# styler: on


aflh({
  isfris %>%
    # comment
    tjnfaxasf12af7987A() %>% # comment
    tjnfaxdfaasfaf7987A() %>%
    tjnfxasfaf798fA() %>%
    tf797A() %>% # more
    # comment
    yyexprzB()
})


# styler: off
aflh({
  isfris %>%
    # comment
    tjnfaxasf12af7987A %>%
    tjnfaxdfaasfaf7987A %>%
    tjnfxasfaf798fA %>%
    # more
    tf797A %>% # comments
    # here
    yyexprzB #
  # whatnot
})
# styler: on


aflh({
  isfris %>%
    # comment
    tjnfaxasf12af7987A %>%
    tjnfaxdfaasfaf7987A %>%
    tjnfxasfaf798fA %>%
    # more
    tf797A %>% # comments
    # here
    yyexprzB #
  # whatnot
})
