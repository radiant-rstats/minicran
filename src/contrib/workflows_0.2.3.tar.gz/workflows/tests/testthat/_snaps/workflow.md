# model spec is validated

    Code
      workflow(spec = 1)
    Error <rlang_error>
      `spec` must be a `model_spec`.

# preprocessor is validated

    Code
      workflow(preprocessor = 1)
    Error <rlang_error>
      `preprocessor` must be a formula, recipe, or a set of workflow variables.

# input must be a workflow

    `x` must be a workflow, not a numeric.

