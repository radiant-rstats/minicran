.onLoad <- function(lib, pkg) {
  library.dynam("acepack", pkg, lib)
}
