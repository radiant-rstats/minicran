#' Internal Functions Used in timetk
#'
#' The following are internal functions that are not meant to be used by
#' users.
#'
#' @inheritParams tk_zooreg
#'
#' @name timetk_internal
#'
NULL
