# order_by() give meaningful errors

    Code
      order_by(NULL, 1L)
    Error <rlang_error>
      `call` must be a function call, not an integer vector.

