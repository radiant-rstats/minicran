cat("In tests/testthat/helpers-devel-options: ")
cache_deactivate()

styler_version <- utils::packageDescription("styler", fields = "Version")
