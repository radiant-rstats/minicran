This directory contains some utilities that are not essential for LibSass.

# perl update-builds.pl

This will update 3rd party build files from `Makefile.conf`, which
is the master index file for all required sources and headers.
