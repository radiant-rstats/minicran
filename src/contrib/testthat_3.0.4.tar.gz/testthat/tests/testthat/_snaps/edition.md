# deprecation only fired for newer edition

    Code
      edition_deprecate(3, "old stuff")
    Warning <warning>
      `old stuff` was deprecated in the 3rd edition.

