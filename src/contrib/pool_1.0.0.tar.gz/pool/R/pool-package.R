#' @docType package
#' @keywords internal
"_PACKAGE"

#' @import DBI
#' @import methods
#' @importFrom R6 R6Class
#' @importFrom later later
#' @import rlang
NULL
