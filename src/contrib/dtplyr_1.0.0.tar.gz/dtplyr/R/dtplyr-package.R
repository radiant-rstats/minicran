#' @import rlang
#' @importFrom data.table data.table as.data.table .SD copy is.data.table
"_PACKAGE"

#' @export
.datatable.aware <- TRUE

globalVariables(".N")
