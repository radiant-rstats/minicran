#' @import rlang
#' @importFrom purrr map2
#' @importFrom purrr map
#' @importFrom purrr map_chr
#' @importFrom purrr map_lgl
#' @importFrom purrr reduce
#' @importFrom utils head
#' @importFrom stats predict
#' @importFrom stats qt
#' @importFrom knitr knit_print
#' @importFrom dplyr mutate
#' @keywords internal
#'
"_PACKAGE"
NULL
utils::globalVariables(c("."))
