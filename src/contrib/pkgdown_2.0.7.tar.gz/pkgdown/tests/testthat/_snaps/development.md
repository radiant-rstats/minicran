# bad mode yields good error

    Code
      check_mode("foo")
    Condition
      Error in `check_mode()`:
      ! `development.mode` in `_pkgdown.yml` must be one of auto, default, release, devel, unreleased

