# vec_depth() is deprecated

    Code
      . <- vec_depth(list())
    Condition
      Warning:
      `vec_depth()` was deprecated in purrr 1.0.0.
      i Please use `pluck_depth()` instead.

