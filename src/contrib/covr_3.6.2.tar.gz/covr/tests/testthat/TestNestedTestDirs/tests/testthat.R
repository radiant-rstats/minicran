library(testthat)
library("TestNestedTestDirs")

test_check("TestNestedTestDirs")
