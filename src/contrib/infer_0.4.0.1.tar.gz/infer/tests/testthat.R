library(testthat)
library(infer)

suppressWarnings(RNGversion("3.5.0"))
test_check("infer")
