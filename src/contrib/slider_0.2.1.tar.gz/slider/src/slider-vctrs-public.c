#include <vctrs.c>

void slider_initialize_vctrs_public() {
  vctrs_init_api();
}
