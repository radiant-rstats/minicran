# tsfeatures (development version)

## Bug fixes

* Better handling of perfect fits in `arch_stat()`

# tsfeatures 1.0.1

* Bug fixes
* Documentation improvements

# tsfeatures 1.0.0

* First release
