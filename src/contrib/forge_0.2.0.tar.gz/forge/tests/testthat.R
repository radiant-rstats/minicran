library(testthat)
library(forge)

test_check("forge")
