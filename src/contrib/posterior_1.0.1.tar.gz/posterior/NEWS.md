# posterior 1.0.1

* ensure that all unit tests pass on all CRAN environments
* fix a problem that sometimes lead to `rvar`s being unnecessarily slow (#179)

# posterior 1.0.0

* initial CRAN release


# posterior 0.1.0

* beta release
