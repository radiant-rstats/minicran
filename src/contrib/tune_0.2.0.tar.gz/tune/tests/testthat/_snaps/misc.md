# empty ellipses

    Code
      tune:::empty_ellipses(a = 1)
    Warning <rlang_warning>
      The `...` are not used in this function but one or more objects were passed: 'a'

