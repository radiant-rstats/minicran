library(testthat)
library(odbc)

test_check("odbc")
