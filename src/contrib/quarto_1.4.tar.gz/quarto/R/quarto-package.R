#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import rlang
#' @importFrom cli cli_inform
#' @importFrom tools vignetteEngine
## usethis namespace: end
NULL
