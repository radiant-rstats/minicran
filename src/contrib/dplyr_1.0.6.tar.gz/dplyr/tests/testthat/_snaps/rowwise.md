# rowwise has decent print method

    Code
      rf
    Output
      # A tibble: 5 x 1
      # Rowwise:  x
            x
        <int>
      1     1
      2     2
      3     3
      4     4
      5     5

