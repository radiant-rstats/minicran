source("incl/start.R")

library(future)
supportedStrategies <- function(...) future:::supportedStrategies()

isWin32 <- FALSE
availCores <- 2L

message("*** Demos ...")

message("*** Mandelbrot demo ...")

if (!isWin32) {
  options(future.demo.mandelbrot.nrow = 2L)
  options(future.demo.mandelbrot.resolution = 50L)
  options(future.demo.mandelbrot.delay = FALSE)
  
  for (cores in 1:availCores) {
    message(sprintf("Testing with %d cores ...", cores))
    options(mc.cores = cores)
  
    for (strategy in supportedStrategies(cores)) {
      message(sprintf("- plan('%s') ...", strategy))
      plan(strategy)
      demo("mandelbrot", package = "progressr", ask = FALSE)
      message(sprintf("- plan('%s') ... DONE", strategy))
    }
  
    message(sprintf("Testing with %d cores ... DONE", cores))
  } ## for (cores ...)
} else {
  message(" - This demo requires R (>= 3.2.0). Skipping test. (Skipping also on Win32 i386 for speed)")
}

message("*** Mandelbrot demo ... DONE")

message("*** Demos ... DONE")

source("incl/end.R")
