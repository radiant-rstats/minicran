# check for bad options

    The following options cannot be used as arguments for `fit_resamples()` or the `tune_*()` functions: 'grid2'

---

    The following options cannot be used as arguments for `fit_resamples()` or the `tune_*()` functions: 'blueprint'

