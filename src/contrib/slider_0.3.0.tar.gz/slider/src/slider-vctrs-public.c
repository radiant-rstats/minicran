#include <vctrs.c>

void slider_initialize_vctrs_public(void) {
  vctrs_init_api();
}
