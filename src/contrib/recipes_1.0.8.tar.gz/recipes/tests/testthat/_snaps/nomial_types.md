# missing factors

    Code
      check_nominal_type(te, rec$orig_lvls)
    Condition
      Warning:
       There were 2 columns that were factors when the recipe was prepped:
       'city', 'zip'.
       This may cause errors when processing new data.

# missing factors with skipping

    Code
      check_nominal_type(te, rec$orig_lvls)
    Condition
      Warning:
       There were 2 columns that were factors when the recipe was prepped:
       'city', 'zip'.
       This may cause errors when processing new data.

