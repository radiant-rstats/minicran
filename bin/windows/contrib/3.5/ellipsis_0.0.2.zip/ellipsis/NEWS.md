# ellipsis 0.0.2

* Fix a `PROTECT`ion error
