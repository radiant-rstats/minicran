#' Models for scaling and classification of textual data
#' 
#' The `textmodel_*()` functions formerly in \pkg{quanteda} have now been moved 
#' to the \pkg{quanteda.textmodels} package.
#' @name textmodels
#' @seealso `quanteda.textmodels::quanteda.textmodels-package`
NULL
