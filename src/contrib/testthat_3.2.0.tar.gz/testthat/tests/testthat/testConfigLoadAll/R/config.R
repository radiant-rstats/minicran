internal <- function() NULL

#' @export
exported <- function() NULL
