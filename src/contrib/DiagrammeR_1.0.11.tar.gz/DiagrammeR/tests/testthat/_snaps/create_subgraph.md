# a subgraph can be created and such an object is correct

    Code
      transform_to_subgraph_ws(graph)
    Condition
      Error in `transform_to_subgraph_ws()`:
      ! There is no selection of node or edges available.

