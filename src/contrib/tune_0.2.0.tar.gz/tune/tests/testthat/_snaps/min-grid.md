# linear regression grid reduction - glmnet

    Code
      min_grid(mod, data.frame(mixture = 1:3))
    Error <rlang_error>
      At least one penalty value is required for glmnet.

# logistic regression grid reduction - glmnet

    Code
      min_grid(mod, data.frame(mixture = 1:3))
    Error <rlang_error>
      At least one penalty value is required for glmnet.

# multinomial regression grid reduction - glmnet

    Code
      min_grid(mod, data.frame(mixture = 1:3))
    Error <rlang_error>
      At least one penalty value is required for glmnet.

