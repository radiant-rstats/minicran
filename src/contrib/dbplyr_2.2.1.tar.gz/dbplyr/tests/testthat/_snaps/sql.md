# can format sql

    Code
      sql()
    Output
      <SQL> [empty]

---

    Code
      sql(a = "x", "y")
    Output
      <SQL> x AS a
      <SQL> y AS 

