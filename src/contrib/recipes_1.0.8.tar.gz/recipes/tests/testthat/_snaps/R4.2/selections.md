# simple name selections

    Code
      recipes_eval_select(quos = quos(I(beds:sqft)), data = Sacramento, info = info_sac)
    Condition
      Error:
      ! Problem while evaluating `I(beds:sqft)`.
      Caused by error in `unique.default()`:
      ! object 'beds' not found

