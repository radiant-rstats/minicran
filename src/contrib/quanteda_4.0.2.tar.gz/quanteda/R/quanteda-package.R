#' @keywords internal
"_PACKAGE"

#' @name quanteda
#' @rdname quanteda-package
NULL

## usethis namespace: start
#' @importFrom lifecycle deprecated
## usethis namespace: end
NULL
