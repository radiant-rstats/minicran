#' @export
#' @importFrom ggdist stat_interval
ggdist::stat_interval

#' @export
#' @importFrom ggdist StatInterval
ggdist::StatInterval
