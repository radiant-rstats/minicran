library(testthat)
library(rstan)

test_check("rstan")
