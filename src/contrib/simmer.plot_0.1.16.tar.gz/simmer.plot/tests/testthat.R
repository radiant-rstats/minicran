library(testthat)
library(simmer.plot)

test_check("simmer.plot")
