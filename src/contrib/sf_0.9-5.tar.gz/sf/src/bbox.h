Rcpp::NumericVector CPL_get_bbox(Rcpp::List sf, int depth);
