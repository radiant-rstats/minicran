library(testthat)
library(influenceR)

test_check("influenceR")

