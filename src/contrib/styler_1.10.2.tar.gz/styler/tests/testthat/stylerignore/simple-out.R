call(1 ) # styler: off
# styler: off
# also if there are more comments
test_xkj("hier", na.rm = 3, py = 43
         )


x="new" # styler: off
y=1 # none

more_calls(with(arguments))
# styler: on
1 + 1
a(!b)


# --------
x="new" # styler: off
y <- 1 # none

more_calls(with(arguments))
# styler: off
1 + 1
a(!b)
