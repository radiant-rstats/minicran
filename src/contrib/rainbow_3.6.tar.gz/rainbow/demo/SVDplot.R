## This demo consider functional data visualization---singular value 
## decomposition plot

library(rainbow)

SVDplot(ElNinosmooth)
SVDplot(ElNinosmooth, plot.type = "image")
