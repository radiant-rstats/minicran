# Model can be saved and re-loaded

    Code
      tidypredict_fit(pm)
    Output
      1 - 1/(1 + exp(24.1453276 + (wt * -7.8977178) + (disp * -0.0269566) + 
          (ifelse(cyl == "cyl6", 1, 0) * 4.8670863) + (ifelse(cyl == 
          "cyl8", 1, 0) * 10.9478336)))

