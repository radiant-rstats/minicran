/* C-level API that is called from R */
SEXP R_test_tcp_port(SEXP port);
