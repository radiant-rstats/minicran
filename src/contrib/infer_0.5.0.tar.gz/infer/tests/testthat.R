library(testthat)
library(infer)

# Use fixed method of generating from a discrete uniform distribution
RNGversion("3.5.0")

test_check("infer")
