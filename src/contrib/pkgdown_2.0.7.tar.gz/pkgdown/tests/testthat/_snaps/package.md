# check_bootstrap_version() gives informative error otherwise

    Code
      check_bootstrap_version(1)
    Condition
      Error in `check_bootstrap_version()`:
      ! Boostrap version must be 3 or 5.
      x You specified a value of 1 in template.bootstrap.

