% NLOPT_GN_DIRECT_L_RAND: Randomized DIRECT-L (global, no-derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_GN_DIRECT_L_RAND
  val = 2;
