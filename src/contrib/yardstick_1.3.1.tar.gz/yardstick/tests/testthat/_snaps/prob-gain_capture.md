# errors with class_pred input

    Code
      gain_capture_vec(cp_truth, estimate)
    Condition
      Error in `gain_capture_vec()`:
      ! `truth` should not a <class_pred> object.

