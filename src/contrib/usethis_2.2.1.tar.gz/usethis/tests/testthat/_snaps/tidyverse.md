# use_tidy_dependencies() isn't overly informative

    Code
      use_tidy_dependencies()
    Message
      v Adding 'rlang' to Imports field in DESCRIPTION
      v Adding 'lifecycle' to Imports field in DESCRIPTION
      v Adding 'cli' to Imports field in DESCRIPTION
      v Adding 'glue' to Imports field in DESCRIPTION
      v Adding 'withr' to Imports field in DESCRIPTION
      v Adding '@import rlang' to 'R/{TESTPKG}-package.R'
      v Adding '@importFrom glue glue' to 'R/{TESTPKG}-package.R'
      v Adding '@importFrom lifecycle deprecated' to 'R/{TESTPKG}-package.R'
      v Writing 'NAMESPACE'
      v Writing 'R/import-standalone-purrr.R'

