c(
  "x",       "z",
  "cgjhg", "thi", "z"
)


c(
  "x",       "z",
  "cgjhg",  "thi", "z"
)


c(
  "x", "y", "z",  "m", "n",  "o", "p",
  "c", "d"
)
