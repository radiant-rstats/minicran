library(testthat)
library(alphavantager)

test_check("alphavantager")
