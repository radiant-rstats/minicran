# pkgdown_sitrep works

    Code
      pkgdown_sitrep(pkg)
    Condition
      Warning:
      pkgdown situation report: configuration error
      x url in _pkgdown.yml is absent. See `vignette(pkgdown::metadata)`.
      x 'DESCRIPTION' URL is empty.

---

    Code
      pkgdown_sitrep(pkg)
    Condition
      Warning:
      pkgdown situation report: configuration error
      x 'DESCRIPTION' URL is empty.

---

    Code
      pkgdown_sitrep(pkg)
    Message
      v pkgdown situation report: all clear
      ! Double-check the following URLs:
        _pkgdown.yml contains URL <http://example.com/pkg>
        'DESCRIPTION' contains URL <http://example.com/pkg>

