# invalid R syntax
1 +
