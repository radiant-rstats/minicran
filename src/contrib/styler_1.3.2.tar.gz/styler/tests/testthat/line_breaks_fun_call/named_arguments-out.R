call(3,
  b = 2, c
)

gs(3,
  b = 2,
  c
)

call(3, b = 2, c)

map(data, fun,
  x = 3, z = 33
)

map2(
  dat1, data2, fun, x, y,
  z
)

map2(dat1, data2, fun,
  x = 1, y = 2,
  z
)
