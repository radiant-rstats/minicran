# This is a kitten

<img src="man/figures/kitten.jpg" />
