# unnest_tokens raises an error if custom tokenizer gives bad output

    Expected output of tokenizing function to be a list of length 1

---

    Expected output of tokenizing function to be a list of length 1

