# site meta doesn't break unexpectedly

    pandoc: '{version}'
    pkgdown: '{version}'
    pkgdown_sha: '{sha}'
    articles: {}
    last_built: 2020-01-01T00:00Z
    urls:
      reference: http://test.org/reference
      article: http://test.org/articles
    

