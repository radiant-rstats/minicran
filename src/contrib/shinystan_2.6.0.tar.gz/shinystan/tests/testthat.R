library(testthat)
library(shinystan)

test_check("shinystan")
