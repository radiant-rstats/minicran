# Data in Table 2 of Powers (2007)

data_powers <- function() {
  pr_lvs <- c("Relevant", "Irrelevant")

  tbl_2_1_pred <- factor(rep(pr_lvs, times = c(42, 58)), levels = pr_lvs)
  tbl_2_1_pred2 <- tbl_2_1_pred
  tbl_2_1_pred2[c(1, 10, 20, 30, 40, 50)] <- NA
  tbl_2_1_truth <- factor(c(rep(pr_lvs, times = c(30, 12)),
                            rep(pr_lvs, times = c(30, 28))),
                          levels = pr_lvs)
  tbl_2_1 <- table(tbl_2_1_pred, tbl_2_1_truth)
  df_2_1 <- data.frame(truth  = tbl_2_1_truth,
                       prediction = tbl_2_1_pred,
                       pred_na = tbl_2_1_pred2)

  list(tabl_2_1 = tbl_2_1, df_2_1 = df_2_1)
}


data_altman <- function() {
  ## data from: Altman, D.G., Bland, J.M. (1994) ``Diagnostic tests 1:
  #'  sensitivity and specificity,'' *British Medical Journal*,
  #'  vol 308, 1552.

  data(pathology)

  pathology$scan_ch <- as.character(pathology$scan)
  pathology$scan_na <- pathology$scan
  pathology$scan_na[c(1, 250, 300)] <- NA

  path_tbl <- as.table(matrix(c(231, 27, 32, 54), ncol = 2))
  rownames(path_tbl) <- levels(pathology$pathology)
  colnames(path_tbl) <- levels(pathology$pathology)

  list(pathology = pathology, path_tbl = path_tbl)
}

data_three_class <- function() {
  set.seed(1311)
  three_class <- data.frame(obs = iris$Species,
                            pred = sample(iris$Species, replace = TRUE),
                            pred_na = sample(iris$Species))
  three_class$pred_na[sample.int(150, 10)] <- NA
  three_class$pred_ch <- as.character(three_class$pred)
  three_class$pred_lvl <- factor(as.character(three_class$pred),
                                 levels = rev(levels(iris$Species)))
  three_class$pred_val <- three_class$pred_ch
  three_class$pred_val[1] <- "wrong_value"

  three_class_tb <- table(three_class$pred, three_class$obs)

  list(three_class = three_class, three_class_tb = three_class_tb)
}
