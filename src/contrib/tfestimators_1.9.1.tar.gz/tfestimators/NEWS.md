# tfestimators 1.9.1

* Fixes for rlang 0.3 compatibility (#156, #159).

# tfestimators 1.9.0

* Add input checking to exported functions (#150).

* `input_fn.list()` no longer performs type coercion on numpy arrays.

* Added `boosted_trees_regressors()` and `boosted_trees_classifier()` (#146).
