boxcox <-
function (x, ...) 
UseMethod("boxcox")
