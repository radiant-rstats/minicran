# screen_name has print and [ methods

    Code
      x
    Output
      <rwteet_screen_name>
      [1] "123456"

