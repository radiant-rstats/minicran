# recommends use of _PACKAGE

    Code
      out <- parse_text(block)[[1]]
    Message
      x <text>:3: `@docType "package"` is deprecated.
      i Please document "_PACKAGE" instead.

