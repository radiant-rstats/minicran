test(
  "x",
  {

  },
  a + b,
  {
    s(x = sd)
  }
)

test(
  "x",
  {

  },
  a + b,
  {
    s(x = sd)
  }
)

test(
  "x",
  {

  },
  a + b,
  {
    s(x = sd)
  }
)


test(
  "x",
  {

  },
  a + b,
  {
    s(x = sd)
  }
)

test(
  "x",
  {

  }, # h
  a + b,
  {
    s(x = sd)
  }
)

test(
  "x",
  {

  }, # h
  a + b,
  # k
  {
    s(x = sd)
  }
)

test(
  "x",
  {

  },
  a + b, # k
  {
    s(x = sd)
  }
)

tetst(
  "x",
  {
    x
  },
  1 + +1
)
