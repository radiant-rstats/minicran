# survival output

    Code
      pillar(x, width = 20)
    Output
      <pillar>
                    <Surv>
                      306 
                      455 
                     1010+
                      210 
                      883 
                     1022+

---

    Code
      pillar(x, width = 20)
    Output
      <pillar>
                   <Surv2>
                      306 
                      455 
                     1010+
                      210 
                      883 
                     1022+

