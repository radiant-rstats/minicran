# bad mode yields good error

    Code
      check_mode("foo")
    Condition
      Error in `check_mode()`:
      ! development.mode must be one of auto, default, release, devel, or unreleased.
      i Use an approriate value in `_pkgdown.yml`

