#ifndef MATRIX_BIND_H
#define MATRIX_BIND_H

#include "Mutils.h"

SEXP R_bind(SEXP args);

#endif
