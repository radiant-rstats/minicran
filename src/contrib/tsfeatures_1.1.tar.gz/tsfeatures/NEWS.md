# tsfeatures 1.1

* Added zero_proportion
* Replaced deprecated multiprocess
* Bug fixes and documentation improvements

# tsfeatures 1.0.2

* Better handling of perfect fits in `arch_stat()`

# tsfeatures 1.0.1

* Bug fixes
* Documentation improvements

# tsfeatures 1.0.0

* First release
