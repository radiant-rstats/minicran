//
// This file was automatically generated using livy_sources_refresh()
// Changes to this file will be reverted.
//

class Rscript(logger: Logger) {
  import java.io.File

  def getScratchDir(): File = {
    new File("")
  }

  def init(
    params: List[String],
    sourceFilePath: String,
    customEnv: Map[String, String],
    options: Map[String, String]) = {
  }
}

