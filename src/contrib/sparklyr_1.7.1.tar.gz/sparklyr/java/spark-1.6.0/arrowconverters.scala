package sparklyr

object ArrowConverters {
  // unsupported
}

class ArrowConvertersImpl {
  // unsupported
}
