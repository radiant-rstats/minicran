library(testthat)
library(pageviews)

test_check("pageviews")
