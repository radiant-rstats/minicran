foo(
  img,
  pkg = "abc",
  color = "lmn",
  font = "xyz"
)


foo(
  img, #
  pkg = "abc",
  color = "lmn",
  font = "xyz"
)
