# queries translate correctly

    Code
      mf %>% head()
    Output
      <SQL>
      SELECT TOP 6 *
      FROM `df`

