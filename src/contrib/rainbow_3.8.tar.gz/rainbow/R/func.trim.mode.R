`func.trim.mode` <- function(data, trim = 0.25)
{
  depth.mode(data, trim = trim)$mtrim
}

