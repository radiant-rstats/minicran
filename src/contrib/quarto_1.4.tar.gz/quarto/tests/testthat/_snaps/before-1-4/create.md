# create project only available for 1.4

    Code
      quarto_create_project(name = "test")
    Condition
      Error in `check_quarto_version()`:
      ! `quarto create project` has been added in Quarto 1.4. See <https://quarto.org/docs/projects/quarto-projects.html>.
      i You are using <quarto version> from '<quarto full path>'.

