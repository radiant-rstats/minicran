lines.fds <- function(x, type = "l", index, ...)
{
   plot.fds(x=x, type = type, add = TRUE, index = index, ...)
}