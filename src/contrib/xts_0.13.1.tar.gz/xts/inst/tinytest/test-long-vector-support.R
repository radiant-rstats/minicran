if (isTRUE(Sys.getenv("XTS_TEST_LONG_VECTOR_SUPPORT", FALSE))) {

}
