import::from("text.R", print_text)
import::from("title_text.R", print_title_text)

text = "hi friend, how are you"
print_text(text)
print_title_text(text)
