length.list <-
function (...) 
{
    sapply(list(...), length)
}
