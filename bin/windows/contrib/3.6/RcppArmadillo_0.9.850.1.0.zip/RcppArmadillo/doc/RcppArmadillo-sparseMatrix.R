## ----init, echo=FALSE---------------------------------------------------------
library(RcppArmadillo)
library(Matrix)

