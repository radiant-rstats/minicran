get_stream <- function() {
  return(.Call('get_stream_'))
}



