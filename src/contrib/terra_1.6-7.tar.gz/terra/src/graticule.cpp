//#include "spatVector.h"

//SpatVector graticule(SpatExtent ext, std::string crs, size_t nx, size_t ny) {
	//srs s;
	//s.set(crs);

	// get xrange in lon
	// find pretty breaks
	// get yrange in lat

//}


