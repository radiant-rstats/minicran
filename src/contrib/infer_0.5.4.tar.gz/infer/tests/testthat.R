library(testthat)
library(infer)

test_check("infer")


