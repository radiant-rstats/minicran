{
  if (TRUE)
    3
  else
    4
}

{
  if (TRUE) {
    3
  } else
    4
}

{
  if (TRUE)
    3
  else {
    4
  }
}

{
  if (TRUE) {
    3
  } else {
    4
  }
}

# rather space than brace thing, but
foo <- function(x) {
  if (TRUE) {
    1
  } else {
    2
  }
}
