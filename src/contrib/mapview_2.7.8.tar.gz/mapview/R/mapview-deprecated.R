#' Deprecated functions in mapview
#'
#' These functions still work but will be removed (defunct) in the next version.
#' See below for information on which package they have been moved to.
#'
#' \itemize{
#'  \item \code{\link{cubeview}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'cubeview'.
#'  \item \code{\link{cubeView}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'cubeview'.
#'  \item \code{\link{cubeViewOutput}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'cubeview'.
#'  \item \code{\link{renderCubeView}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'cubeview'.
#'  \item \code{\link{slideview}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'slideview'.
#'  \item \code{\link{slideView}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'slideview'.
#'  \item \code{\link{slideViewOutput}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'slideview'.
#'  \item \code{\link{renderslideView}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'slideview'.
#'  \item \code{\link{latticeView}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafsync'.
#'  \item \code{\link{sync}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafsync'.
#'  \item \code{\link{plainview}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'plainview'.
#'  \item \code{\link{plainView}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'plainview'.
#'  \item \code{\link{popupTable}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafpop'.
#'  \item \code{\link{popupImage}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafpop'.
#'  \item \code{\link{popupGraph}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafpop'.
#'  \item \code{\link{addFeatures}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafem'.
#'  \item \code{\link{garnishMap}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafem'.
#'  \item \code{\link{addHomeButton}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafem'.
#'  \item \code{\link{removeHomeButton}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafem'.
#'  \item \code{\link{addImageQuery}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafem'.
#'  \item \code{\link{addLogo}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafem'.
#'  \item \code{\link{addMouseCoordinates}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafem'.
#'  \item \code{\link{removeMouseCoordinates}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafem'.
#'  \item \code{\link{addStaticLabels}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafem'.
#'  \item \code{\link{addExtent}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafem'.
#'  \item \code{\link{addStarsImage}}: This function is deprecated, and will
#'  be removed in the next version of this package. This function has been
#'  migrated to package 'leafem'.
#' }
#'
#' @name mapview-deprecated
NULL
