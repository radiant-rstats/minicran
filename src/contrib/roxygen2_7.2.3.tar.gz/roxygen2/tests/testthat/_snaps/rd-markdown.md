# @title warns about multiple paragraphs

    [<text>:2] @title must be a single paragraph

