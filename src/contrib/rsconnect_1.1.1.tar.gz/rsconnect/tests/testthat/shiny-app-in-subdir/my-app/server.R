# Stub server.R
#
# Its presence (along with ui.R) indicates that this directory contains a
# Shiny application.
