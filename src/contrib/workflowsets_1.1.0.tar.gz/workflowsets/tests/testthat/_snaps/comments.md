# print comments

    Code
      comment_print(test)
    Output
      -- none_cart ------------------------------------------------------------------- 
      
      "Whenever you feel like criticizing any one," he told me, "just
      remember that all the people in this world haven't had the advantages
      that you've had."
      
      My family have been prominent, well-to-do people in this middle-western
      city for three generations. The Carraways are something of a clan and
      we have a tradition that we're descended from the Dukes of Buccleuch,
      but the actual founder of my line was my grandfather's brother who came
      here in fifty-one, sent a substitute to the Civil War and started the
      wholesale hardware business that my father carries on today. 
      
      -- none_glm -------------------------------------------------------------------- 
      
      Across the courtesy bay the white palaces of fashionable East Egg
      glittered along the water, and the history of the summer really begins
      on the evening I drove over there to have dinner with the Tom
      Buchanans. Daisy was my second cousin once removed and I'd known Tom in
      college. And just after the war I spent two days with them in Chicago. 
      

---

    Code
      comment_print(test, id = "none_glm")
    Output
      -- none_glm -------------------------------------------------------------------- 
      
      Across the courtesy bay the white palaces of fashionable East Egg
      glittered along the water, and the history of the summer really begins
      on the evening I drove over there to have dinner with the Tom
      Buchanans. Daisy was my second cousin once removed and I'd known Tom in
      college. And just after the war I spent two days with them in Chicago. 
      

