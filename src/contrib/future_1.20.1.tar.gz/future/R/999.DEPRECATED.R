## - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
## DEPRECATED
## - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#' @export
values <- function(...) {
  .Deprecated(new = "value()", old = "values()", package = .packageName)
  value(...)
}
