# `tidymodels` 0.0.4

 * Updated versions

 * Added `workflows`, and `tune` to the core package list. 

 * Moved away from testing via `travis`

# `tidymodels` 0.0.3

 * Updated versions

# `tidymodels` 0.0.2

 * Added  `parsnip` and `dials` to the core package list. 

 * Package requirements bumped to current versions.


# `tidymodels` 0.0.1

First CRAN version.



