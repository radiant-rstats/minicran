# can handle logo in subdir

    Code
      copy_logo(pkg)
    Message
      Copying man/figures/logo.svg
      to logo.svg

