a <- function(x, y, z) {
  while (2 + 2 > call(3, 1)) {
    if (isTRUE(x)) {
      b
    }
  }
  for (a in 1:19) {
    x[i] + 1
  }
}
