# lift functions are deprecated

    Code
      . <- lift_dl(function() { })
    Condition
      Warning:
      `lift()` was deprecated in purrr 1.0.0.
    Code
      . <- lift_dv(function() { })
    Condition
      Warning:
      `lift_dv()` was deprecated in purrr 1.0.0.
    Code
      . <- lift_vl(function() { })
    Condition
      Warning:
      `lift_vl()` was deprecated in purrr 1.0.0.
    Code
      . <- lift_vd(function() { })
    Condition
      Warning:
      `lift_vd()` was deprecated in purrr 1.0.0.
    Code
      . <- lift_ld(function() { })
    Condition
      Warning:
      `lift_ld()` was deprecated in purrr 1.0.0.
    Code
      . <- lift_lv(function() { })
    Condition
      Warning:
      `lift_lv()` was deprecated in purrr 1.0.0.

