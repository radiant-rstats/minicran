globalVariables(c("index", "index.num", "y", "yhat", "week", "mday", "diff.median", ".",
                  "data", "nested.col", "weekday", "locale", "holiday_name", "values", "value",
                  "holidays", "lag", ".facets_collapsed", ".groups_consolidated", ".value_mod", ".value_smooth", "name",
                  ".group", ".group_value", "feature", "id", "key", "splits",
                  "observed", "remainder", "seasadj", "season", "trend", ".color_mod"))
