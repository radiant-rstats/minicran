#' @docType package
#' @useDynLib collections
#' @importFrom R6 R6Class
"_PACKAGE"
