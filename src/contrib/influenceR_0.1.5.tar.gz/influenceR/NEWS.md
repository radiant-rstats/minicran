# influenceR 0.1.5
* Add badges to README
* Update documentation with Rd.
* include prototype in int_rand() function declaration in keyplayer-utils.c
* fixed compatibility in graphs_defs.h

* Updated maintainer email
* Changed GitHub repository location to https://github.com/khanna-lab/influenceR
* Fixed broken links

# influenceR 0.1.2

* Fixed RChecks package. Current version is 0.2.0
