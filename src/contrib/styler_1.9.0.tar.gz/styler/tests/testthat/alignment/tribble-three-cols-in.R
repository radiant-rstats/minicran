tribble(
  ~x,    ~y,    ~z,
  "one", TRUE,  1L,
  "two", FALSE, 2L
)
