
test_that("snapshot", {
  expect_snapshot(1:10)
})
