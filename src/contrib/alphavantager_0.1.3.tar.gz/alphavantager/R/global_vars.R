globalVariables(c("name", "name1", "timestamp", "value", "change", "rank_group"))
