library(testthat)
library(ggmap)

test_check("ggmap")
