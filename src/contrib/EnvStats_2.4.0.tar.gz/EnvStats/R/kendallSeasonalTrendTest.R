kendallSeasonalTrendTest <-
function (y, ...) 
UseMethod("kendallSeasonalTrendTest")
