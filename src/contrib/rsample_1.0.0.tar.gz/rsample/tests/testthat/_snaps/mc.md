# printing

    Code
      mc_cv(warpbreaks)
    Output
      # Monte Carlo cross-validation (0.75/0.25) with 25 resamples  
      # A tibble: 25 x 2
         splits          id        
         <list>          <chr>     
       1 <split [40/14]> Resample01
       2 <split [40/14]> Resample02
       3 <split [40/14]> Resample03
       4 <split [40/14]> Resample04
       5 <split [40/14]> Resample05
       6 <split [40/14]> Resample06
       7 <split [40/14]> Resample07
       8 <split [40/14]> Resample08
       9 <split [40/14]> Resample09
      10 <split [40/14]> Resample10
      # ... with 15 more rows

