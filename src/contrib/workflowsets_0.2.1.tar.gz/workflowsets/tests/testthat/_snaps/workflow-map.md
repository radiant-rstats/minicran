# map logging

    Code
      cat(logging_res, sep = "\n")
    Output
      i	No tuning parameters. `fit_resamples()` will be attempted
      i 1 of 3 resampling: reg_lm
      i 2 of 3 tuning:     reg_knn
      i	No tuning parameters. `fit_resamples()` will be attempted
      i 3 of 3 resampling: nonlin_lm

