# package install checks

    Code
      dials:::check_installs("pistachio")
    Condition
      Error in `dials:::check_installs()`:
      ! Package(s) not installed: 'pistachio'

