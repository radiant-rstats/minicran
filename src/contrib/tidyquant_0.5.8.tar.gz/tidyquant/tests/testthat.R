library(testthat)
library(tidyquant)
library(tidyverse)

test_check("tidyquant")
