# This file is encoded in Cp-1252

# Comment containing non-ASCII �
a <- 42
