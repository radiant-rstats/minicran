# namespace calls are translated

    There is no package called 'NOSUCHPACKAGE'

---

    'NOSUCHFUNCTION' is not an exported object from 'dbplyr'

---

    No known translation for base::abbreviate()

